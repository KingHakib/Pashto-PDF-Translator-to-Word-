#!/usr/bin/env bash
# End-to-end test: upload real fixtures through the HTTP API, poll jobs,
# download outputs, and verify the translated DOCX contains Pashto text.
set -u
BASE="http://localhost:3000"
FIX="/home/z/my-project/scripts/fixtures"
OUT="/tmp/e2e"
rm -rf "$OUT"; mkdir -p "$OUT"
PASS=0; FAIL=0

declare -a FILES=(
  report-en.docx
  project-fa.docx
  strategy-en.pptx
  inventory-en.xlsx
  guide-en.pdf
  certificate-scan.pdf
  memo-en.txt
  water-fr.txt
  quote-de.html
  press-en.rtf
)

echo "=== uploading ==="
ARGS=()
for f in "${FILES[@]}"; do
  ARGS+=(-F "files=@${FIX}/${f}")
done
RESP=$(curl -s -X POST "$BASE/api/jobs" "${ARGS[@]}" -F targetLang=ps -F retention=after-processing)
echo "$RESP" | python3 -c "
import json,sys
d=json.load(sys.stdin)
if 'error' in d: print('UPLOAD ERROR:', d['error']); sys.exit(1)
print('\n'.join(j['id']+':'+j['originalName'] for j in d['jobs']))
" > "$OUT/jobs.txt" || { echo "upload failed: $RESP"; exit 1; }
cat "$OUT/jobs.txt"

# poll all jobs until finished
echo "=== polling ==="
DEADLINE=$(( $(date +%s) + 1200 ))
while :; do
  PENDING=0
  while IFS= read -r line; do
    ID="${line%%:*}"; NAME="${line#*:}"
    ST=$(curl -s "$BASE/api/jobs/$ID" | python3 -c "
import json,sys
j=json.load(sys.stdin).get('job',{})
print(j.get('status','?'), j.get('progress',0), j.get('segmentsDone',0), j.get('segmentsTotal',0))
")
    STATUS=$(echo "$ST" | cut -d' ' -f1)
    case "$STATUS" in
      done|error|canceled) ;;
      *) PENDING=$((PENDING+1));
         echo "  $NAME -> $ST" ;;
    esac
  done < "$OUT/jobs.txt"
  [ "$PENDING" -eq 0 ] && break
  [ "$(date +%s)" -gt "$DEADLINE" ] && { echo "TIMEOUT waiting for jobs"; break; }
  sleep 12
  echo "  ---"
done

echo "=== downloading + verifying ==="
while IFS= read -r line; do
  ID="${line%%:*}"; NAME="${line#*:}"
  META=$(curl -s "$BASE/api/jobs/$ID")
  echo "$META" > "$OUT/$NAME.meta.json"
  STATUS=$(echo "$META" | python3 -c "import json,sys; print(json.load(sys.stdin)['job']['status'])")
  if [ "$STATUS" != "done" ]; then
    ERR=$(echo "$META" | python3 -c "import json,sys; print(json.load(sys.stdin)['job'].get('error',''))")
    echo "✗ $NAME status=$STATUS error=$ERR"
    FAIL=$((FAIL+1))
    continue
  fi
  mkdir -p "$OUT/$NAME"
  for OUTFILE in translated.docx translated.pdf translated.pptx translated.xlsx; do
    HTTP=$(curl -s -o "$OUT/$NAME/$OUTFILE" -w "%{http_code}" "$BASE/api/jobs/$ID/file?name=$OUTFILE")
    if [ "$HTTP" = "200" ]; then
      echo "  ↓ $NAME/$OUTFILE ($(stat -c%s "$OUT/$NAME/$OUTFILE") bytes)"
    fi
  done
  # verify docx contains Pashto/Arabic script
  RESULT=$(python3 - "$OUT/$NAME/translated.docx" <<'EOF'
import sys, zipfile, re, os
p = sys.argv[1]
if not os.path.exists(p):
    print("MISSING_DOCX"); sys.exit()
try:
    z = zipfile.ZipFile(p)
except Exception as e:
    print("BAD_ZIP", e); sys.exit()
names = z.namelist()
total = 0
for n in names:
    if re.match(r'word/(document|header|footer|footnotes)\d*\.xml', n):
        xml = z.read(n).decode('utf-8', 'ignore')
        rtl = xml.count('<w:bidi/>') + xml.count('<w:bidi ')
        texts = re.findall(r'<w:t[^>]*>([^<]*)</w:t>', xml)
        ar = sum(len(re.findall(r'[\u0600-\u06FF]', t)) for t in texts)
        total += ar
if total > 20:
    print(f"PASHTO_OK chars={total}")
else:
    print(f"NO_PASHTO chars={total}")
EOF
)
  PDF_OK="no-pdf"
  if [ -s "$OUT/$NAME/translated.pdf" ]; then PDF_OK="pdf_ok"; fi
  if echo "$RESULT" | grep -q PASHTO_OK; then
    echo "✓ $NAME $RESULT $PDF_OK"
    PASS=$((PASS+1))
  else
    echo "✗ $NAME verification=$RESULT $PDF_OK"
    FAIL=$((FAIL+1))
  fi
done < "$OUT/jobs.txt"

echo ""
echo "=== summary: PASS=$PASS FAIL=$FAIL ==="
exit $FAIL
