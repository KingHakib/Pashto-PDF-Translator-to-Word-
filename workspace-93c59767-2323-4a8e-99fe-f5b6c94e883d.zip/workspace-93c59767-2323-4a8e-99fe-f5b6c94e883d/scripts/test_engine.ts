/**
 * Engine unit test with MOCK translations (no LLM):
 * validates docx/pptx/xlsx surgery, RTL insertion, and that LibreOffice
 * can still open the produced files (schema-order correctness).
 */
import fs from 'fs';
import path from 'path';
import { translateDocx } from '../src/lib/engine/docx';
import { translatePptx } from '../src/lib/engine/pptx';
import { translateXlsx } from '../src/lib/engine/xlsx';
import { buildRtlDocx } from '../src/lib/engine/builder';
import { sofficeConvert } from '../src/lib/engine/convert';

const FIX = path.join(__dirname, 'fixtures');
const OUT = '/tmp/engine-test';
fs.mkdirSync(OUT, { recursive: true });

function mockTranslateFactory() {
  return async (segments: { id: number; text: string }[]) => {
    const map = new Map<number, string>();
    for (const s of segments) {
      // fake "Pashto" output that includes the original for inspection
      map.set(s.id, `[پ-${s.id}] ${s.text}`);
    }
    return map;
  };
}

async function main() {
  const failures: string[] = [];

  // ---- DOCX ----
  const docxBuf = fs.readFileSync(path.join(FIX, 'report-en.docx'));
  const docxRes = await translateDocx(docxBuf, mockTranslateFactory(), {
    targetRtl: true,
    langBidi: 'ps-AF',
    csFont: 'Tahoma',
  });
  fs.writeFileSync(path.join(OUT, 'report-translated.docx'), docxRes.output);
  console.log(`docx: ${docxRes.segmentCount} segments, ${docxRes.output.length} bytes`);
  const docxXml = docxRes.output.toString('latin1'); // zip is binary; check via unzip instead
  void docxXml;
  const conv = await sofficeConvert(
    path.join(OUT, 'report-translated.docx'),
    OUT,
    'pdf',
    path.join(OUT, 'lo1'),
    120_000,
  );
  console.log('docx→pdf conversion:', conv.ok ? 'OK' : `FAIL: ${conv.log.slice(-400)}`);
  if (!conv.ok) failures.push('translated docx failed LibreOffice conversion (likely invalid XML/schema order)');

  // original must still convert (sanity)
  const conv2 = await sofficeConvert(path.join(FIX, 'report-en.docx'), OUT, 'pdf', path.join(OUT, 'lo2'), 120_000);
  console.log('original docx→pdf conversion:', conv2.ok ? 'OK' : 'FAIL');

  // ---- PPTX ----
  const pptxBuf = fs.readFileSync(path.join(FIX, 'strategy-en.pptx'));
  const pptxRes = await translatePptx(pptxBuf, mockTranslateFactory(), {
    targetRtl: true,
    langTag: 'ps-AF',
    csFont: 'Tahoma',
  });
  fs.writeFileSync(path.join(OUT, 'strategy-translated.pptx'), pptxRes.output);
  console.log(`pptx: ${pptxRes.segmentCount} segments, ${pptxRes.output.length} bytes`);
  const conv3 = await sofficeConvert(path.join(OUT, 'strategy-translated.pptx'), OUT, 'pdf', path.join(OUT, 'lo3'), 120_000);
  console.log('pptx→pdf conversion:', conv3.ok ? 'OK' : `FAIL: ${conv3.log.slice(-400)}`);
  if (!conv3.ok) failures.push('translated pptx failed LibreOffice conversion');

  // ---- XLSX ----
  const xlsxBuf = fs.readFileSync(path.join(FIX, 'inventory-en.xlsx'));
  const xlsxRes = await translateXlsx(xlsxBuf, mockTranslateFactory());
  fs.writeFileSync(path.join(OUT, 'inventory-translated.xlsx'), xlsxRes.output);
  console.log(`xlsx: ${xlsxRes.segmentCount} segments, ${xlsxRes.output.length} bytes`);
  const conv4 = await sofficeConvert(path.join(OUT, 'inventory-translated.xlsx'), OUT, 'pdf', path.join(OUT, 'lo4'), 120_000);
  console.log('xlsx→pdf conversion:', conv4.ok ? 'OK' : `FAIL: ${conv4.log.slice(-400)}`);
  if (!conv4.ok) failures.push('translated xlsx failed LibreOffice conversion');

  // ---- Builder ----
  const built = await buildRtlDocx([
    [{ type: 'heading', level: 1, text: 'د ازمویشن سرلیک' }, { type: 'para', text: 'دا یوه ازمویشتي فقره ده. شمېرې: 2025' }],
    [{ type: 'para', text: 'دوهم مخ', pageBreakBefore: true }],
  ]);
  fs.writeFileSync(path.join(OUT, 'built.docx'), built);
  const conv5 = await sofficeConvert(path.join(OUT, 'built.docx'), OUT, 'pdf', path.join(OUT, 'lo5'), 120_000);
  console.log('built docx→pdf conversion:', conv5.ok ? 'OK' : `FAIL: ${conv5.log.slice(-400)}`);
  if (!conv5.ok) failures.push('built docx failed LibreOffice conversion');

  // ---- legacy doc/rft/html conversions from fixtures ----
  for (const [f, target] of [['press-en.rtf', 'docx'], ['quote-de.html', 'docx']] as const) {
    const c = await sofficeConvert(path.join(FIX, f), OUT, target, path.join(OUT, `lo-${f}`), 120_000);
    console.log(`${f}→${target}:`, c.ok ? 'OK' : `FAIL: ${c.log.slice(-300)}`);
    if (!c.ok) failures.push(`${f} conversion failed`);
  }

  console.log(failures.length === 0 ? '\nALL ENGINE TESTS PASSED' : `\nFAILURES:\n- ${failures.join('\n- ')}`);
  process.exit(failures.length === 0 ? 0 : 1);
}

main().catch((e) => {
  console.error('Test crashed:', e);
  process.exit(1);
});
