#!/usr/bin/env python3
"""Create realistic test documents in multiple formats and languages
for end-to-end testing of the Pashto translation pipeline."""
import os
import sys

OUT = os.path.join(os.path.dirname(__file__), 'fixtures')
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- EN docx
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

def make_docx_en():
    doc = Document()
    # heading + colored/bold runs + table + bullets
    h = doc.add_heading('Quarterly Business Report', level=1)
    p = doc.add_paragraph()
    run = p.add_run('Prepared by: ')
    run.bold = True
    p.add_run('Ahmad Khan, Operations Director')
    p2 = doc.add_paragraph(
        'This report summarizes the performance of the organization during the second '
        'quarter of 2025. Revenue grew by 14.7% compared to the same period last year, '
        'reaching USD 4.2 million. The education and logistics departments performed '
        'particularly well, while the agriculture sector faced challenges due to drought.'
    )
    p2.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    doc.add_heading('1. Key Indicators', level=2)
    table = doc.add_table(rows=4, cols=3)
    table.style = 'Table Grid'
    hdr = table.rows[0].cells
    hdr[0].text = 'Department'
    hdr[1].text = 'Revenue (USD)'
    hdr[2].text = 'Growth'
    rows = [
        ('Education', '1,800,000', '+21%'),
        ('Logistics', '1,450,000', '+12%'),
        ('Agriculture', '950,000', '-3%'),
    ]
    for i, r in enumerate(rows, start=1):
        cells = table.rows[i].cells
        for j, v in enumerate(r):
            cells[j].text = v
    doc.add_heading('2. Recommendations', level=2)
    doc.add_paragraph('Expand the scholarship program to 500 additional students.', style='List Bullet')
    doc.add_paragraph('Open two new distribution centers in Kabul and Herat.', style='List Bullet')
    doc.add_paragraph('Renegotiate supplier contracts before December 2025.', style='List Bullet')
    footer = doc.sections[0].footer
    footer.paragraphs[0].text = 'Confidential — Internal use only | Page 1'
    doc.save(os.path.join(OUT, 'report-en.docx'))

# ---------------------------------------------------------------- FA docx (RTL source)
def make_docx_fa():
    doc = Document()
    doc.add_heading('گزارش پروژه بازسازی مدرسه', level=1)
    doc.add_paragraph(
        'بدین‌وسیله گزارش پیشرفت پروژه بازسازی مکتب سلطان غیاث‌الدین بلحکم به اطلاع می‌رساند. '
        'کار ساختمانی طبقه اول در ماه جون 2025 ختم و مصارف آن بالغ بر 250,000 افغانی گردید.'
    )
    doc.add_paragraph('مسئول پروژه: انجنیر محمد نعیم')
    doc.save(os.path.join(OUT, 'project-fa.docx'))

# ---------------------------------------------------------------- PPTX
def make_pptx():
    from pptx import Presentation
    prs = Presentation()
    s1 = prs.slides.add_slide(prs.slide_layouts[0])
    s1.shapes.title.text = 'Digital Transformation Strategy'
    s1.placeholders[1].text = 'Ministry of Communications — 2025 Kickoff'
    s2 = prs.slides.add_slide(prs.slide_layouts[1])
    s2.shapes.title.text = 'Three Strategic Pillars'
    body = s2.placeholders[1].text_frame
    body.text = 'Connect 5,000 villages to broadband internet'
    body.add_paragraph().text = 'Digitize 80% of public services by 2027'
    body.add_paragraph().text = 'Train 10,000 civil servants in digital skills'
    s3 = prs.slides.add_slide(prs.slide_layouts[1])
    s3.shapes.title.text = 'Budget Overview'
    s3.placeholders[1].text_frame.text = 'Total investment: USD 120 million over 3 years'
    prs.save(os.path.join(OUT, 'strategy-en.pptx'))

# ---------------------------------------------------------------- XLSX
def make_xlsx():
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = 'Inventory'
    ws.append(['Item', 'Category', 'Quantity', 'Unit Price (AFN)'])
    ws.append(['School Books', 'Education', 1200, 350])
    ws.append(['Whiteboard', 'Education', 45, 2100])
    ws.append(['Generator', 'Energy', 8, 68000])
    ws2 = wb.create_sheet('Summary')
    ws2.append(['Metric', 'Value'])
    ws2.append(['Total items', 1253])
    ws2.append(['Report date', '2025-06-30'])
    wb.save(os.path.join(OUT, 'inventory-en.xlsx'))

# ---------------------------------------------------------------- text PDF (reportlab)
def make_pdf_text():
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import cm
    from reportlab.pdfgen import canvas
    path = os.path.join(OUT, 'guide-en.pdf')
    c = canvas.Canvas(path, pagesize=A4)
    w, h = A4

    def page1():
        c.setFont('Helvetica-Bold', 20)
        c.drawString(2*cm, h-3*cm, 'Farmer Field Guide')
        c.setFont('Helvetica', 11)
        c.drawString(2*cm, h-3.8*cm, 'Wheat Cultivation in Temperate Climates — 3rd Edition')
        c.setFont('Helvetica-Bold', 13)
        c.drawString(2*cm, h-5*cm, '1. Soil Preparation')
        c.setFont('Helvetica', 11)
        text = [
            'Wheat grows best in well-drained loamy soil with a pH between 6.0 and 7.5.',
            'Plough the field twice and level it carefully before sowing. Add 200 kg of',
            'di-ammonium phosphate (DAP) per hectare during the final ploughing.',
        ]
        y = h - 5.8*cm
        for line in text:
            c.drawString(2*cm, y, line)
            y -= 0.6*cm
        c.setFont('Helvetica-Bold', 13)
        c.drawString(2*cm, y-0.5*cm, '2. Sowing Calendar')
        c.setFont('Helvetica', 11)
        y -= 1.3*cm
        rows = [
            ('Region', 'Sowing window', 'Seed rate'),
            ('Kabul plateau', 'October 15 - November 5', '120 kg/ha'),
            ('Eastern valleys', 'November 1 - December 1', '100 kg/ha'),
        ]
        x0 = 2*cm
        for i, row in enumerate(rows):
            for j, cell in enumerate(row):
                c.drawString(x0 + j*4.5*cm, y, cell)
            y -= 0.55*cm
        c.showPage()

    def page2():
        c.setFont('Helvetica-Bold', 13)
        c.drawString(2*cm, h-3*cm, '3. Irrigation and Harvest')
        c.setFont('Helvetica', 11)
        lines = [
            'Apply the first irrigation 21 days after sowing. A total of four irrigations',
            'are usually sufficient. Harvest when the grain moisture drops below 14%.',
            'Expected yield under good management: 4.5 to 5.5 tonnes per hectare.',
            '',
            'Contact: Agricultural Extension Office, Phone: +93 700 123 456',
        ]
        y = h - 3.8*cm
        for line in lines:
            c.drawString(2*cm, y, line)
            y -= 0.6*cm
        c.showPage()

    page1()
    page2()
    c.save()

# ---------------------------------------------------------------- scanned PDF (image-only)
def make_pdf_scanned():
    from PIL import Image, ImageDraw, ImageFont
    import img2pdf
    pages = []
    texts = [
        [
            'CERTIFICATE OF COMPLETION',
            '',
            'This is to certify that',
            'Fatima Rahimi',
            'has successfully completed the training course',
            'Introduction to Project Management',
            'with a final score of 94 out of 100.',
            '',
            'Kabul, Afghanistan - 15 July 2025',
        ],
        [
            'TRAINING RECORD',
            '',
            'Course duration: 40 hours',
            'Trainer: Dr. Sadiq Wardak',
            'Organization: Kabul Institute of Management',
            'Certificate No: KM-2025-0417',
        ],
    ]
    try:
        font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf', 34)
        font_s = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf', 26)
    except Exception:
        font = font_s = None
    for text in texts:
        img = Image.new('RGB', (1240, 1754), 'white')
        d = ImageDraw.Draw(img)
        y = 260
        for line in text:
            if not line:
                y += 30
                continue
            f = font if line.isupper() or 'CERTIFICATE' in line else font_s
            d.text((120, y), line, fill='black', font=f)
            y += 64
        p = os.path.join(OUT, f'_scan_tmp_{len(pages)}.png')
        img.save(p)
        pages.append(p)
    with open(os.path.join(OUT, 'certificate-scan.pdf'), 'wb') as f:
        f.write(img2pdf.convert(pages))
    for p in pages:
        os.unlink(p)

# ---------------------------------------------------------------- TXT
def make_txt():
    content = """COMMUNITY WATER PROJECT — STATUS UPDATE

The Community Water Project started in March 2025 with funding from the
development partners. So far, 12 wells have been drilled in three districts,
providing clean drinking water to approximately 8,400 families.

Budget execution stands at 68% of the approved USD 1.9 million. The remaining
funds are allocated for the solar-powered pumping stations scheduled for
installation before winter.

Contact: Eng. Zubair Ahmadi, Project Coordinator"""
    with open(os.path.join(OUT, 'water-fr.txt'), 'w') as f:
        # write a mix: label says fr but let's make it actual French to test detection
        f.write("""PROJET D'EAU COMMUNAUTAIRE — POINT DE SITUATION

Le projet d'eau communautaire a démarré en mars 2025 avec le financement des
partenaires du développement. Jusqu'à présent, 12 puits ont été forés dans trois
districts, fournissant de l'eau potable propre à environ 8 400 familles.

L'exécution budgétaire atteint 68 % du montant approuvé de 1,9 million USD.
Les fonds restants sont destinés aux stations de pompage solaires qui seront
installées avant l'hiver.

Contact : M. Zubair Ahmadi, coordinateur du projet""")
    # English txt too
    with open(os.path.join(OUT, 'memo-en.txt'), 'w') as f:
        f.write(content)

# ---------------------------------------------------------------- HTML
def make_html():
    html = """<!DOCTYPE html>
<html lang="de">
<head><meta charset="utf-8"><title>Angebotsübersicht</title></head>
<body>
<h1>Angebotsübersicht: Schulbauprojekt</h1>
<p>Sehr geehrte Damen und Herren,</p>
<p>hiermit übersenden wir unser Angebot für den Bau der Grundschule in Mazar-e-Sharif.
Die Gesamtkosten betragen 4.800.000 AFN und die Bauzeit beträgt 14 Monate.</p>
<table border="1">
<tr><th>Position</th><th>Kosten (AFN)</th></tr>
<tr><td>Bauarbeiten</td><td>3.200.000</td></tr>
<tr><td>Einrichtung</td><td>900.000</td></tr>
<tr><td>Projektmanagement</td><td>700.000</td></tr>
</table>
<p>Mit freundlichen Grüßen,<br>Bauunternehmen Noorzai GmbH</p>
</body></html>"""
    with open(os.path.join(OUT, 'quote-de.html'), 'w') as f:
        f.write(html)

# ---------------------------------------------------------------- RTF
def make_rtf():
    rtf = r"""{\rtf1\ansi\deff0
{\fonttbl{\f0 Times New Roman;}}
\f0\fs28 PRESS RELEASE\par
\par
\fs22 The Ministry of Public Health announced today the opening of a new
100-bed hospital in Jalalabad. The facility will provide maternal care,
emergency surgery and a vaccination center for children under five years old.\par
\par
The project cost USD 6.5 million and was completed in 26 months.\par
}"""
    with open(os.path.join(OUT, 'press-en.rtf'), 'w') as f:
        f.write(rtf)

if __name__ == '__main__':
    which = sys.argv[1:] or ['all']
    if 'all' in which or 'docx' in which: make_docx_en(); make_docx_fa()
    if 'all' in which or 'pptx' in which: make_pptx()
    if 'all' in which or 'xlsx' in which: make_xlsx()
    if 'all' in which or 'pdf' in which: make_pdf_text(); make_pdf_scanned()
    if 'all' in which or 'txt' in which: make_txt()
    if 'all' in which or 'html' in which: make_html()
    if 'all' in which or 'rtf' in which: make_rtf()
    print('fixtures in', OUT)
    for f in sorted(os.listdir(OUT)):
        print(' ', f, os.path.getsize(os.path.join(OUT, f)), 'bytes')
