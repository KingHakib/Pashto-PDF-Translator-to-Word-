#!/usr/bin/env python3
"""Bridge: convert a (text-based) PDF to DOCX with layout preservation.
Used by the Node pipeline via child_process. pdf2docx keeps page geometry,
tables, images and fonts far better than any Draw-based roundtrip."""
import json
import logging
import sys

logging.disable(logging.CRITICAL)


def main() -> int:
    if len(sys.argv) < 3:
        print(json.dumps({"ok": False, "error": "usage: pdf2docx_bridge.py SRC DST"}))
        return 2
    src, dst = sys.argv[1], sys.argv[2]
    try:
        from pdf2docx import Converter

        cv = Converter(src)
        cv.convert(dst)
        cv.close()
        print(json.dumps({"ok": True}))
        return 0
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"ok": False, "error": str(exc)[:300]}))
        return 1


if __name__ == "__main__":
    sys.exit(main())
