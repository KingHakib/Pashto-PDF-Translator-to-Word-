/**
 * Translation job store: filesystem-backed metadata, queue, retention and GC.
 * Each job lives in .data/jobs/<id>/ with meta.json, the original upload,
 * outputs/ and previews/. A lazy GC enforces the user-selected retention
 * policy for original files and a hard 7-day cap for finished jobs.
 */
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

export const DATA_DIR = path.join(process.cwd(), '.data', 'jobs');
export const MAX_JOBS_KEPT = 200;
const JOB_TTL_MS = 7 * 24 * 3600 * 1000;

export type JobStatus =
  | 'queued'
  | 'analyzing'
  | 'converting'
  | 'extracting'
  | 'detecting'
  | 'translating'
  | 'rebuilding'
  | 'exporting'
  | 'done'
  | 'error'
  | 'canceled';

export type Retention = 'after-processing' | '24h' | 'after-download' | 'keep';

export interface JobMeta {
  id: string;
  originalName: string;
  ext: string;
  size: number;
  targetLang: string;
  retention: Retention;
  status: JobStatus;
  stage: string;
  progress: number; // 0..100
  sourceLang?: { code: string; name: string; confidence: string } | null;
  alreadyTarget?: boolean;
  pageCount?: number;
  segmentsTotal?: number;
  segmentsDone?: number;
  ocr?: { used: boolean; script?: string; langs?: string; lowConfidencePages?: number };
  warnings: string[];
  outputs: string[];       // file names inside outputs/
  previews: { original: number; translated: number };
  error?: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
  originalDeleted?: boolean;
}

const registry = new Map<string, JobMeta>();
let gcTimer: NodeJS.Timeout | null = null;

export function jobDir(id: string): string {
  return path.join(DATA_DIR, id);
}
export function originalPath(meta: Pick<JobMeta, 'id' | 'ext'>): string {
  return path.join(jobDir(meta.id), `original.${meta.ext}`);
}
export function outputsDir(id: string): string {
  return path.join(jobDir(id), 'outputs');
}
export function previewsDir(id: string): string {
  return path.join(jobDir(id), 'previews');
}
export function workDir(id: string): string {
  return path.join(jobDir(id), 'work');
}

function validId(id: string): boolean {
  return /^[a-f0-9-]{36}$/.test(id);
}

function persist(meta: JobMeta): void {
  fs.mkdirSync(jobDir(meta.id), { recursive: true });
  fs.writeFileSync(path.join(jobDir(meta.id), 'meta.json'), JSON.stringify(meta, null, 2));
}

export function createJob(params: {
  originalName: string;
  ext: string;
  size: number;
  targetLang: string;
  retention: Retention;
}): JobMeta {
  const id = crypto.randomUUID();
  const now = Date.now();
  const meta: JobMeta = {
    id,
    originalName: params.originalName,
    ext: params.ext,
    size: params.size,
    targetLang: params.targetLang,
    retention: params.retention,
    status: 'queued',
    stage: 'Queued',
    progress: 0,
    warnings: [],
    outputs: [],
    previews: { original: 0, translated: 0 },
    createdAt: now,
    updatedAt: now,
  };
  fs.mkdirSync(outputsDir(id), { recursive: true });
  fs.mkdirSync(previewsDir(id), { recursive: true });
  registry.set(id, meta);
  persist(meta);
  return meta;
}

export function getJob(id: string): JobMeta | null {
  if (!validId(id)) return null;
  // always read from disk: multiple module copies (dev HMR) and processes
  // may exist; meta.json is the single source of truth.
  const file = path.join(jobDir(id), 'meta.json');
  if (!fs.existsSync(file)) {
    registry.delete(id);
    return null;
  }
  try {
    const meta = JSON.parse(fs.readFileSync(file, 'utf-8')) as JobMeta;
    registry.set(id, meta);
    return meta;
  } catch {
    return null;
  }
}

export function listJobs(): JobMeta[] {
  const ids = new Set<string>();
  try {
    for (const dir of fs.readdirSync(DATA_DIR)) {
      if (/^[a-f0-9-]{36}$/.test(dir)) ids.add(dir);
    }
  } catch {
    /* dir missing */
  }
  const jobs: JobMeta[] = [];
  for (const id of ids) {
    const meta = getJob(id);
    if (meta) jobs.push(meta);
  }
  jobs.sort((a, b) => b.createdAt - a.createdAt);
  return jobs;
}

export function updateJob(id: string, patch: Partial<JobMeta>): JobMeta | null {
  const meta = getJob(id);
  if (!meta) return null;
  Object.assign(meta, patch, { updatedAt: Date.now() });
  persist(meta);
  return meta;
}

export function addWarnings(id: string, warnings: string[]): void {
  const meta = getJob(id);
  if (!meta || warnings.length === 0) return;
  meta.warnings.push(...warnings);
  persist(meta);
}

/** Atomically move a queued job to "analyzing" (claim marker for the runner). */
export function claimQueuedJob(id: string): boolean {
  if (!validId(id)) return false;
  const meta = getJob(id);
  if (!meta || meta.canceled || meta.status !== 'queued') return false;
  meta.status = 'analyzing';
  meta.stage = 'Starting';
  meta.updatedAt = Date.now();
  persist(meta);
  return true;
}

export function deleteJob(id: string): boolean {
  const meta = getJob(id);
  if (!meta) return false;
  registry.delete(id);
  try {
    fs.rmSync(jobDir(id), { recursive: true, force: true });
  } catch {
    /* ignore */
  }
  return true;
}

export function deleteOriginalFile(id: string): void {
  const meta = getJob(id);
  if (!meta || meta.originalDeleted) return;
  try {
    fs.rmSync(originalPath(meta), { force: true });
    meta.originalDeleted = true;
    persist(meta);
  } catch {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ */
/* Retention / garbage collection                                      */
/* ------------------------------------------------------------------ */

export function runRetentionSweep(): void {
  const now = Date.now();
  for (const meta of listJobs()) {
    // hard cap: finished jobs disappear after 7 days
    const finishedAt = meta.completedAt ?? meta.updatedAt;
    if (
      (meta.status === 'done' || meta.status === 'error' || meta.status === 'canceled') &&
      now - finishedAt > JOB_TTL_MS
    ) {
      deleteJob(meta.id);
      continue;
    }
    // user retention policy for the ORIGINAL file
    if (!meta.originalDeleted && meta.status === 'done') {
      if (meta.retention === 'after-processing') deleteOriginalFile(meta.id);
      if (meta.retention === '24h' && meta.completedAt && now - meta.completedAt > 24 * 3600 * 1000) {
        deleteOriginalFile(meta.id);
      }
    }
  }
  // bound total count
  const jobs = listJobs();
  if (jobs.length > MAX_JOBS_KEPT) {
    for (const meta of jobs.slice(MAX_JOBS_KEPT)) deleteJob(meta.id);
  }
}

export function ensureStore(): void {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!gcTimer) {
    gcTimer = setInterval(() => runRetentionSweep(), 10 * 60 * 1000);
    gcTimer.unref?.();
    setTimeout(() => runRetentionSweep(), 5_000).unref?.();
  }
}

/** sanitize user filename for display while keeping readable info */
export function safeOriginalName(name: string): string {
  return name.replace(/[\\/]/g, '_').slice(0, 180);
}
