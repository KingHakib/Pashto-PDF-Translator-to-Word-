/**
 * Job pipeline: analyze → convert → extract/detect → translate → rebuild →
 * export (DOCX + PDF + native) → previews. Runs asynchronously per job with
 * progress reporting and cancellation support.
 */
import fs from 'fs';
import path from 'path';
import {
  addWarnings,
  claimQueuedJob,
  getJob,
  jobDir,
  listJobs,
  outputsDir,
  previewsDir,
  updateJob,
  workDir,
  type JobMeta,
} from './store';
import {
  CHILD_ENV,
  fileMagic,
  pdfExtractText,
  pdfPageCount,
  renderPdfPages,
  run,
  sofficeConvert,
} from '../engine/convert';
import { ocrPdf } from '../engine/ocr';
import { translateDocx, type SegmentTranslateFn } from '../engine/docx';
import { translatePptx, pptxSlideTexts } from '../engine/pptx';
import { translateXlsx, xlsxSheetTexts } from '../engine/xlsx';
import { buildRtlDocx, type BuilderBlock } from '../engine/builder';
import {
  detectLanguage,
  getTargetLang,
  translateSegments,
} from '../translate/engine';

const PDF2DOCX_BRIDGE = path.join(process.cwd(), 'assets', 'pdf2docx_bridge.py');

const MAX_PAGES = 300;
const PREVIEW_PAGES = 3;

/* ------------------------------------------------------------------ */
/* Translation session: detection + translation shared across formats  */
/* ------------------------------------------------------------------ */

class TranslationSession {
  sourceLang: { code: string; name: string; confidence: string } | null = null;
  alreadyTarget = false;
  warnings: string[] = [];

  constructor(
    private jobId: string,
    private targetCode: string,
  ) {}

  buildTranslateFn(): SegmentTranslateFn {
    return async (segments, onProgress) => {
      updateJob(this.jobId, {
        status: 'detecting',
        stage: 'Detecting source language',
        segmentsTotal: segments.length,
      });
      const sample = segments
        .slice(0, 12)
        .map((s) => s.text)
        .join('\n')
        .slice(0, 1500);
      let sourceName = 'Unknown';
      try {
        this.sourceLang = await detectLanguage(sample);
        sourceName = this.sourceLang.name;
      } catch {
        this.sourceLang = { code: 'unknown', name: 'Unknown', confidence: 'low' };
      }
      const target = getTargetLang(this.targetCode);
      this.alreadyTarget =
        sourceName.toLowerCase().includes(target.name.toLowerCase()) ||
        (target.code === 'fa' && sourceName.toLowerCase().includes('persian'));

      updateJob(this.jobId, {
        status: 'translating',
        stage: `Translating ${sourceName} → ${target.name}`,
        sourceLang: this.sourceLang,
        alreadyTarget: this.alreadyTarget,
      });

      const result = await translateSegments(segments, {
        target,
        sourceLangName: sourceName,
        canceled: () => isDead(this.jobId),
        onProgress: (done, total) => {
          updateJob(this.jobId, { segmentsDone: done });
          onProgress?.(done, total);
        },
      });
      this.warnings.push(...result.warnings);
      if (this.alreadyTarget) {
        this.warnings.unshift(
          `The document is already in ${target.name}; text was kept unchanged and RTL formatting was applied/verified.`,
        );
      }
      return result.translations;
    };
  }
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function setStage(id: string, status: JobMeta['status'], stage: string, progress: number): void {
  updateJob(id, { status, stage, progress });
}

/** a job is dead when canceled OR deleted from the store (zombie protection) */
function isDead(id: string): boolean {
  const meta = getJob(id);
  return !meta || meta.canceled === true;
}

function checkCanceled(id: string): void {
  if (isDead(id)) throw new Error('CANCELED');
}

async function countConvertedDocxText(docxPath: string): Promise<number> {
  try {
    const JSZip = (await import('jszip')).default;
    const zip = await JSZip.loadAsync(fs.readFileSync(docxPath));
    const xml = await zip.file('word/document.xml')?.async('string');
    if (!xml) return 0;
    const matches = xml.match(/<w:t[^>]*>([^<]*)<\/w:t>/g) ?? [];
    return matches.reduce((sum, m) => sum + Math.max(0, m.length - 20), 0);
  } catch {
    return 0;
  }
}

async function makePreviews(
  id: string,
  originalPathForPreview: string | null,
  translatedDocx: string | null,
  isPdfOriginal: boolean,
): Promise<{ original: number; translated: number }> {
  const out = { original: 0, translated: 0 };
  const pDir = previewsDir(id);
  fs.mkdirSync(pDir, { recursive: true });

  const renderFromPdf = async (pdf: string, prefix: string) => {
    const files = await renderPdfPages(pdf, pDir, prefix, { pages: PREVIEW_PAGES, dpi: 85 });
    return files.length;
  };

  // original previews
  if (originalPathForPreview && fs.existsSync(originalPathForPreview)) {
    try {
      if (isPdfOriginal) {
        out.original = await renderFromPdf(originalPathForPreview, 'orig');
      } else {
        const conv = await sofficeConvert(
          originalPathForPreview,
          workDir(id),
          'pdf',
          path.join(workDir(id), 'lo-preview'),
        );
        if (conv.ok && conv.output) out.original = await renderFromPdf(conv.output, 'orig');
      }
    } catch {
      /* preview is best-effort */
    }
  }

  // translated previews
  if (translatedDocx && fs.existsSync(translatedDocx)) {
    try {
      const conv = await sofficeConvert(
        translatedDocx,
        workDir(id),
        'pdf',
        path.join(workDir(id), 'lo-preview'),
        300_000,
      );
      if (conv.ok && conv.output) {
        // keep this PDF as the downloadable PDF version
        fs.copyFileSync(conv.output, path.join(outputsDir(id), 'translated.pdf'));
        out.translated = await renderFromPdf(conv.output, 'trans');
      }
    } catch {
      /* preview is best-effort */
    }
  }
  return out;
}

/* ------------------------------------------------------------------ */
/* Main pipeline                                                       */
/* ------------------------------------------------------------------ */

export async function runJob(id: string): Promise<void> {
  console.log(`[pipeline] runJob enter ${id}`);
  const meta = getJob(id);
  if (!meta || meta.canceled) {
    console.log(`[pipeline] runJob ${id}: missing/canceled, aborting`);
    return;
  }
  const work = workDir(id);
  const outDir = outputsDir(id);
  fs.mkdirSync(work, { recursive: true });
  const origPath = path.join(jobDir(id), `original.${meta.ext}`);

  try {
    const target = getTargetLang(meta.targetLang);
    const session = new TranslationSession(id, meta.targetLang);
    const translateFn = session.buildTranslateFn();

    const buf = fs.readFileSync(origPath);
    const magic = fileMagic(buf);
    const ext = meta.ext.toLowerCase();
    let originalIsPdf = ext === 'pdf';
    let workDocx: string | null = null;           // docx to translate (path in work/)
    let nativeHandler: 'pptx' | 'xlsx' | null = null;
    let nativeWork: string | null = null;          // pptx/xlsx to translate

    /* ---------------- 1. analyze ---------------- */
    setStage(id, 'analyzing', 'Analyzing document', 4);
    checkCanceled(id);

    let pageCount: number | undefined;
    if (ext === 'pdf' && magic === 'pdf') {
      pageCount = await pdfPageCount(origPath);
      if (pageCount > MAX_PAGES) {
        throw new Error(
          `This PDF has ${pageCount} pages. Documents above ${MAX_PAGES} pages are not supported in this version.`,
        );
      }
    } else if (ext === 'pdf') {
      throw new Error('The uploaded file is not a valid PDF.');
    }

    /* ---------------- 2. route / convert to docx ---------------- */
    const convertToDocx = async (from: string): Promise<string> => {
      setStage(id, 'converting', 'Converting to editable format', 10);
      // sofficeConvert locks the soffice mutex internally - never wrap it again
      const res = await sofficeConvert(from, work, 'docx', path.join(work, 'lo'), 300_000);
      if (!res.ok || !res.output) throw new Error('Format conversion failed: ' + res.log.slice(-300));
      return res.output;
    };

    /** text-based PDF → DOCX via pdf2docx (keeps layout, tables, images) */
    const convertPdfToDocx = async (from: string): Promise<string> => {
      setStage(id, 'converting', 'Rebuilding PDF layout in Word format', 10);
      const dst = path.join(work, `${path.basename(from, '.pdf')}.docx`);
      const res = await run('python3', [PDF2DOCX_BRIDGE, from, dst], { timeoutMs: 600_000 });
      let ok = false;
      let err = '';
      try {
        const parsed = JSON.parse(res.stdout.trim().split('\n').pop() ?? '{}');
        ok = parsed.ok === true;
        err = parsed.error ?? '';
      } catch {
        err = res.stderr.slice(-200);
      }
      if (ok && fs.existsSync(dst)) return dst;
      throw new Error(`PDF conversion failed: ${err || 'unknown error'}`);
    };

    if (ext === 'docx' && magic === 'zip') {
      workDocx = origPath; // translate in place (output written separately)
    } else if (ext === 'doc' || ((ext === 'docx' || ext === 'rtf' || ext === 'html' || ext === 'odt') && magic !== 'zip')) {
      workDocx = await convertToDocx(origPath);
    } else if (ext === 'rtf' || ext === 'html' || ext === 'odt') {
      workDocx = await convertToDocx(origPath);
    } else if (ext === 'pptx' && magic === 'zip') {
      nativeHandler = 'pptx';
      nativeWork = origPath;
    } else if (ext === 'ppt' || (ext === 'pptx' && magic !== 'zip')) {
      setStage(id, 'converting', 'Converting legacy PowerPoint', 10);
      const res = await sofficeConvert(origPath, work, 'pptx', path.join(work, 'lo'), 300_000);
      if (!res.ok || !res.output) throw new Error('PPT conversion failed: ' + res.log.slice(-300));
      nativeHandler = 'pptx';
      nativeWork = res.output;
    } else if (ext === 'xlsx' && magic === 'zip') {
      nativeHandler = 'xlsx';
      nativeWork = origPath;
    } else if (ext === 'xls' || (ext === 'xlsx' && magic !== 'zip')) {
      setStage(id, 'converting', 'Converting legacy Excel', 10);
      const res = await sofficeConvert(origPath, work, 'xlsx', path.join(work, 'lo'), 300_000);
      if (!res.ok || !res.output) throw new Error('XLS conversion failed: ' + res.log.slice(-300));
      nativeHandler = 'xlsx';
      nativeWork = res.output;
    } else if (ext === 'pdf') {
      // text-based or scanned?
      setStage(id, 'analyzing', 'Checking PDF text layer', 8);
      const sample = await pdfExtractText(origPath, 1, Math.min(5, pageCount ?? 5));
      const charsPerPage = sample.replace(/\s/g, '').length / Math.max(1, Math.min(5, pageCount ?? 5));
      if (charsPerPage > 30) {
        // text-based PDF: rebuild the layout in Word format with pdf2docx
        const conv = await convertPdfToDocx(origPath);
        const textLen = await countConvertedDocxText(conv);
        if (textLen > 100) {
          workDocx = conv;
        } else {
          throw new Error('FALLBACK_OCR');
        }
      } else {
        throw new Error('FALLBACK_OCR');
      }
    } else if (ext === 'txt' && (magic === 'text' || magic === 'rtf')) {
      workDocx = null; // handled below
    } else {
      // last resort: try LibreOffice conversion for uncommon formats
      try {
        workDocx = await convertToDocx(origPath);
      } catch {
        throw new Error(
          `Unsupported or corrupted file format (.${ext}). Supported: PDF, DOCX, DOC, PPTX, PPT, XLSX, XLS, TXT, RTF, HTML, ODT.`,
        );
      }
    }

    /* ---------------- 3. extract + translate + rebuild ---------------- */
    checkCanceled(id);
    let outputs: string[] = [];

    if (nativeHandler === 'pptx' && nativeWork) {
      const input = fs.readFileSync(nativeWork);
      const { output, segmentCount } = await translatePptx(input, translateFn, {
        targetRtl: target.rtl,
        langTag: target.langTag,
        csFont: 'Tahoma',
      });
      fs.writeFileSync(path.join(outDir, 'translated.pptx'), output);
      outputs.push('translated.pptx');
      // Word reading rendition (texts were already replaced in the pptx)
      const slides = await pptxSlideTexts(output);
      const blocks: BuilderBlock[][] = [];
      let firstSlide = true;
      for (const slide of slides) {
        const pageBlocks: BuilderBlock[] = [];
        if (!firstSlide) {
          // page break is added via pageBreakBefore on first block below
        }
        pageBlocks.push({
          type: 'heading',
          level: 1,
          text: slide.title || `Slide`,
          pageBreakBefore: !firstSlide,
        });
        firstSlide = false;
        for (const p of slide.paragraphs.slice(1)) pageBlocks.push({ type: 'para', text: p });
        blocks.push(pageBlocks);
      }
      const rendition = await buildRtlDocx(blocks);
      fs.writeFileSync(path.join(outDir, 'translated.docx'), rendition);
      outputs.push('translated.docx');
      updateJob(id, { segmentsTotal: segmentCount, segmentsDone: segmentCount, pageCount: slides.length });
    } else if (nativeHandler === 'xlsx' && nativeWork) {
      const input = fs.readFileSync(nativeWork);
      const { output, segmentCount } = await translateXlsx(input, translateFn, {
        onProgress: (info) => {
          if (info.phase === 'translate' && info.total) {
            updateJob(id, { segmentsDone: info.done, segmentsTotal: info.total });
          }
        },
      });
      fs.writeFileSync(path.join(outDir, 'translated.xlsx'), output);
      outputs.push('translated.xlsx');
      const sheets = await xlsxSheetTexts(output);
      const blocks: BuilderBlock[][] = [];
      let first = true;
      for (const sheet of sheets) {
        const pageBlocks: BuilderBlock[] = [];
        pageBlocks.push({
          type: 'heading',
          level: 1,
          text: sheet.name,
          pageBreakBefore: !first,
        });
        first = false;
        for (const row of sheet.rows) pageBlocks.push({ type: 'para', text: row });
        blocks.push(pageBlocks);
      }
      const rendition = await buildRtlDocx(blocks);
      fs.writeFileSync(path.join(outDir, 'translated.docx'), rendition);
      outputs.push('translated.docx');
      updateJob(id, { segmentsTotal: segmentCount, segmentsDone: segmentCount, pageCount: sheets.length });
    } else if (ext === 'txt' && !workDocx) {
      setStage(id, 'extracting', 'Extracting text', 15);
      const raw = buf.toString('utf-8');
      const lines = raw.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
      if (lines.length === 0) throw new Error('The text file is empty.');
      const segments = lines.map((text, idx) => ({ id: idx, text }));
      updateJob(id, { segmentsTotal: segments.length });
      const translations = await translateFn(segments, (done, total) =>
        updateJob(id, { segmentsDone: done, segmentsTotal: total }),
      );
      setStage(id, 'rebuilding', 'Building Word document', 88);
      const blocks: BuilderBlock[][] = [
        segments.map((s) => ({ type: 'para' as const, text: translations.get(s.id) ?? s.text })),
      ];
      const docxBuf = await buildRtlDocx(blocks);
      fs.writeFileSync(path.join(outDir, 'translated.docx'), docxBuf);
      outputs.push('translated.docx');
    } else if (workDocx) {
      // DOCX-family translation (docx/doc/rtf/html/odt/pdf-text)
      const input = fs.readFileSync(workDocx);
      const { output, segmentCount } = await translateDocx(input, translateFn, {
        targetRtl: target.rtl,
        langBidi: target.langTag,
        csFont: 'Tahoma',
        onProgress: (info) => {
          if (info.phase === 'translate' && info.total) {
            updateJob(id, { segmentsDone: info.done, segmentsTotal: info.total });
          }
        },
      });
      fs.writeFileSync(path.join(outDir, 'translated.docx'), output);
      outputs.push('translated.docx');
      updateJob(id, { segmentsTotal: segmentCount, segmentsDone: segmentCount });
    } else {
      throw new Error('No processing path for this file.');
    }

    checkCanceled(id);

    /* ---------------- 4. scanned PDF / OCR fallback ---------------- */
    // handled before? If FALLBACK_OCR was thrown above we need a separate flow:
    // (implemented via catch below to keep the flow linear)

    /* ---------------- 5. PDF export + previews ---------------- */
    setStage(id, 'exporting', 'Creating PDF and previews', 92);
    const transDocx = outputs.includes('translated.docx')
      ? path.join(outDir, 'translated.docx')
      : null;

    const previewCounts = await makePreviews(
      id,
      fs.existsSync(origPath) ? origPath : null,
      transDocx,
      originalIsPdf,
    );
    if (fs.existsSync(path.join(outDir, 'translated.pdf'))) outputs.push('translated.pdf');

    if (session.warnings.length > 0) addWarnings(id, session.warnings);

    const done = getJob(id)!;
    updateJob(id, {
      status: 'done',
      stage: 'Completed',
      progress: 100,
      outputs: [...new Set(outputs)],
      previews: previewCounts,
      pageCount: pageCount ?? done.pageCount,
      completedAt: Date.now(),
    });

    // retention: delete original right away if requested
    if (done.retention === 'after-processing') {
      const { deleteOriginalFile } = await import('./store');
      deleteOriginalFile(id);
    }
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);

    if (message === 'CANCELED') {
      updateJob(id, { status: 'canceled', stage: 'Canceled', completedAt: Date.now() });
      return;
    }

    if (message === 'FALLBACK_OCR') {
      try {
        await runOcrFallback(id, origPath, meta.targetLang);
        return;
      } catch (ocrErr) {
        const ocrMsg = ocrErr instanceof Error ? ocrErr.message : String(ocrErr);
        updateJob(id, {
          status: 'error',
          stage: 'Failed',
          error: ocrMsg,
          completedAt: Date.now(),
        });
        return;
      }
    }

    updateJob(id, {
      status: 'error',
      stage: 'Failed',
      error: message,
      completedAt: Date.now(),
    });
  } finally {
    // cleanup work dir (LibreOffice profiles, temp conversions)
    try {
      fs.rmSync(work, { recursive: true, force: true });
    } catch {
      /* ignore */
    }
  }
}

/* ------------------------------------------------------------------ */
/* OCR fallback: scanned PDFs                                          */
/* ------------------------------------------------------------------ */

async function runOcrFallback(id: string, pdfPath: string, targetCode: string): Promise<void> {
  const meta = getJob(id)!;
  const target = getTargetLang(targetCode);
  const work = workDir(id);
  const outDir = outputsDir(id);
  fs.mkdirSync(work, { recursive: true });

  updateJob(id, { ocr: { used: true } });
  const pageCount = await pdfPageCount(pdfPath);
  updateJob(id, { pageCount });

  const { pages, scripts, langUsed } = await ocrPdf(pdfPath, path.join(work, 'ocr'), Math.min(pageCount, MAX_PAGES), (done, total) => {
    setStage(id, 'extracting', `OCR: reading page ${done}/${total}`, 8 + Math.round((done / Math.max(1, total)) * 22));
  });

  const lowConf = pages.filter((p) => {
    const valid = p.paragraphs.filter((q) => q.confidence > 0);
    if (valid.length === 0) return p.paragraphs.length === 0;
    return valid.reduce((s, q) => s + q.confidence, 0) / valid.length < 55;
  }).length;

  updateJob(id, { ocr: { used: true, script: scripts[0], langs: langUsed, lowConfidencePages: lowConf } });

  // collect text as segments
  const segments: { id: number; text: string }[] = [];
  for (const page of pages) {
    for (const para of page.paragraphs) {
      if (para.text.trim().length > 0) segments.push({ id: segments.length, text: para.text.trim() });
    }
  }
  if (segments.length === 0) {
    throw new Error('OCR could not extract any readable text from this scanned PDF.');
  }

  checkCanceled(id);
  updateJob(id, { segmentsTotal: segments.length, status: 'detecting', stage: 'Detecting source language' });

  const session = new TranslationSession(id, targetCode);
  const translations = await session.buildTranslateFn()(segments, (done, total) =>
    updateJob(id, { segmentsDone: done, segmentsTotal: total, status: 'translating' }),
  );

  checkCanceled(id);
  setStage(id, 'rebuilding', 'Building Word document', 88);

  // group paragraphs into pages for the output document
  const docPages: BuilderBlock[][] = [];
  let segIdx = 0;
  for (const page of pages) {
    const blocks: BuilderBlock[] = [];
    let firstOfPage = true;
    for (const para of page.paragraphs) {
      const seg = segments[segIdx++];
      if (!seg) break;
      blocks.push({
        type: 'para',
        text: translations.get(seg.id) ?? seg.text,
        pageBreakBefore: firstOfPage && docPages.length > 0,
      });
      firstOfPage = false;
    }
    if (blocks.length > 0) docPages.push(blocks);
  }

  const docxBuf = await buildRtlDocx(docPages);
  fs.writeFileSync(path.join(outDir, 'translated.docx'), docxBuf);

  if (session.warnings.length > 0) addWarnings(id, session.warnings);
  if (lowConf > 0) {
    addWarnings(id, [
      `${lowConf} scanned page(s) had low OCR confidence - please review those pages against the original.`,
    ]);
  }

  // previews (original from the PDF itself)
  setStage(id, 'exporting', 'Creating PDF and previews', 94);
  const previewCounts = await makePreviews(id, fs.existsSync(pdfPath) ? pdfPath : null, path.join(outDir, 'translated.docx'), true);
  const outputs = ['translated.docx'];
  if (fs.existsSync(path.join(outDir, 'translated.pdf'))) outputs.push('translated.pdf');

  updateJob(id, {
    status: 'done',
    stage: 'Completed',
    progress: 100,
    outputs,
    previews: previewCounts,
    segmentsDone: segments.length,
    completedAt: Date.now(),
  });
  if (meta.retention === 'after-processing') {
    const { deleteOriginalFile } = await import('./store');
    deleteOriginalFile(id);
  }
}

/* ------------------------------------------------------------------ */
/* Queue                                                               */
/* ------------------------------------------------------------------ */

/* ---------------- queue: store-backed ----------------
 * The store (meta.json on disk) is the single source of truth. "queued"
 * status = waiting; a runner claims a job with an atomic status transition.
 * This survives dev hot-reloads and server restarts without losing jobs. */

interface QueueState {
  activeIds: Set<string>;
  watchdogScheduled: boolean;
}
const g = globalThis as unknown as { __pashtolensQueue?: Partial<QueueState> };
// normalize the shape (older versions of this module may have left a
// different object on globalThis - never trust its shape)
const queueState: QueueState = {
  activeIds:
    g.__pashtolensQueue?.activeIds instanceof Set ? g.__pashtolensQueue.activeIds : new Set<string>(),
  watchdogScheduled: false,
};
g.__pashtolensQueue = queueState;
const { activeIds } = queueState;
const MAX_CONCURRENT_JOBS = 2;

function pump(): void {
  if (activeIds.size >= MAX_CONCURRENT_JOBS) return;
  const candidates = listJobs()
    .filter((m) => m.status === 'queued' && !activeIds.has(m.id))
    .sort((a, b) => a.createdAt - b.createdAt);
  for (const m of candidates) {
    if (activeIds.size >= MAX_CONCURRENT_JOBS) break;
    if (activeIds.has(m.id)) continue;
    if (!claimQueuedJob(m.id)) continue;
    activeIds.add(m.id);
    console.log(`[pipeline] starting job ${m.id} (${m.originalName}, active=${activeIds.size})`);
    runJob(m.id)
      .catch((e) => console.log(`[pipeline] job ${m.id} crashed:`, e))
      .finally(() => {
        activeIds.delete(m.id);
        pump();
      });
  }
}

// watchdog: free slots of dead jobs and pick up newly queued work
if (!queueState.watchdogScheduled) {
  queueState.watchdogScheduled = true;
  setInterval(() => {
    for (const id of [...activeIds]) {
      const meta = getJob(id);
      if (!meta || meta.canceled) {
        console.log(`[pipeline] watchdog freeing slot of dead job ${id}`);
        activeIds.delete(id);
      }
    }
    pump();
  }, 15_000).unref?.();
}

export function enqueueJob(_id?: string): void {
  // job meta already exists with status "queued"; just kick the scheduler
  setImmediate(() => pump());
}

export function cancelJob(id: string): boolean {
  const meta = getJob(id);
  if (!meta) return false;
  if (['done', 'error', 'canceled'].includes(meta.status)) return false;
  updateJob(id, { canceled: true });
  if (meta.status === 'queued') {
    const idx = queue.indexOf(id);
    if (idx >= 0) queue.splice(idx, 1);
    updateJob(id, { status: 'canceled', stage: 'Canceled', completedAt: Date.now() });
  }
  return true;
}
