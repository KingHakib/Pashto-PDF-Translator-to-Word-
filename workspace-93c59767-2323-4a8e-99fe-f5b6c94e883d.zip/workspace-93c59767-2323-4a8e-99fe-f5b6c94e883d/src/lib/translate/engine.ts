/**
 * AI translation engine built on z-ai-web-dev-sdk (GLM).
 *
 * - Robust batching: consecutive segments are packed into numbered JSON
 *   requests so every segment is translated with its surrounding document
 *   context (important for PDFs converted line-by-line and table cells).
 * - Concurrency-limited parallel requests, retries with backoff, timeouts.
 * - Passthrough rules keep numbers, URLs, e-mails, identifiers untouched.
 * - Deterministic deduplication of identical strings.
 * - Failed segments fall back to the original text and produce a warning
 *   (missing-text detection surfaced in the UI).
 */
import ZAI from 'z-ai-web-dev-sdk';

export interface TargetLang {
  code: string;
  name: string;
  native: string;
  rtl: boolean;
  langTag: string;   // Word proofing tag, e.g. ps-AF
  instruction: string;
  glossary?: string;
}

export const TARGET_LANGS: TargetLang[] = [
  {
    code: 'ps',
    name: 'Pashto',
    native: 'پښتو',
    rtl: true,
    langTag: 'ps-AF',
    instruction:
      'Pashto (Afghan Pashto) as written in Afghanistan, using standard Pashto orthography and the Arabic script',
    glossary:
      'Use standard Afghan Pashto terminology for document elements: Table=جدول, Figure=انځور, Page=مخ, Pages=مخونه, Chapter=فصل, Section=برخه, Appendix=ضمیمه, Introduction=پېژندنه, Conclusion=پایله, Summary=لنډیز, References=سرچینې, Ministry=وزارت, Ministry of Education=د پوهنې وزارت, Government=حکومت, University=پوهنتون, Student=زده کوونکی, Teacher=ښوونکی, Report=راپور, Contract=تړون, Invoice=بیل, Date=نیټه, Name=نوم, Address=پته, Signature=لاسلیک, Total=ټول, Amount=مقدار, Year=کال, Month=میاشت, Subject=موضوع, Quarterly=درې میاشتنۍ, Business=سوداګریز, Prepared by=چمتو کړی, Growth=وده, Revenue=عواید, Department=دپارتمان/ریاست, Digital=دیجیټل, Transformation=بدلون, Strategy=استراتیژي, Communications=مخابرات, Budget=بودجه, Investment=پانګونه, Certificate=شهادت نامه, Completion=بشپړول, Training=روزنه, Score=نمره, Item=توکی, Quantity=تعداد, Price=قیمت, Recommendation=وړاندیز, Indicator=شاخص, Project=پروژه, Development=پراختیا, Water=اوبه, Health=روغتیا, Education=زده کړه, Community=کلیواله ټولنه, Village=کلی, District=ولسوالۍ, Province=ولایت, Engineer=انجنیر, Director=رییس, Manager=مدیر, Meeting=غونډه, Plan=پلان, Goal=موخه, Result=پایله, Status=وضعیت, Update=نوی معلوم/تازه.',
  },
  {
    code: 'fa',
    name: 'Dari (Persian)',
    native: 'دری',
    rtl: true,
    langTag: 'fa-IR',
    instruction: 'Dari (Afghan Persian) in standard Perso-Arabic script',
  },
  {
    code: 'ar',
    name: 'Arabic',
    native: 'العربية',
    rtl: true,
    langTag: 'ar-SA',
    instruction: 'Modern Standard Arabic',
  },
  {
    code: 'en',
    name: 'English',
    native: 'English',
    rtl: false,
    langTag: 'en-US',
    instruction: 'English',
  },
];

export function getTargetLang(code: string): TargetLang {
  return TARGET_LANGS.find((l) => l.code === code) ?? TARGET_LANGS[0];
}

/* ------------------------------------------------------------------ */

let zaiPromise: Promise<ZAI> | null = null;
async function getZai(): Promise<ZAI> {
  if (!zaiPromise) zaiPromise = ZAI.create();
  return zaiPromise;
}

/** simple concurrency limiter */
export class Semaphore {
  private active = 0;
  private queue: (() => void)[] = [];
  constructor(private limit: number) {}
  async acquire(): Promise<() => void> {
    return new Promise((resolve) => {
      const tryStart = () => {
        if (this.active < this.limit) {
          this.active++;
          resolve(() => {
            this.active--;
            const next = this.queue.shift();
            if (next) next();
          });
        } else {
          this.queue.push(tryStart);
        }
      };
      tryStart();
    });
  }
}

const llmSemaphore = new Semaphore(3);

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

async function chatWithRetry(
  messages: { role: 'assistant' | 'user'; content: string }[],
  attempts = 6,
  timeoutMs = 150_000,
  shouldAbort?: () => boolean,
): Promise<string> {
  let lastError: Error | null = null;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    if (shouldAbort?.()) throw new Error('ABORTED');
    const release = await llmSemaphore.acquire();
    try {
      const zai = await getZai();
      const result = await Promise.race([
        zai.chat.completions.create({
          messages: messages as never,
          thinking: { type: 'disabled' },
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('LLM request timeout')), timeoutMs),
        ),
      ]);
      const content = (result as { choices?: { message?: { content?: string } }[] })
        ?.choices?.[0]?.message?.content;
      if (!content || content.trim().length === 0) throw new Error('empty LLM response');
      return content;
    } catch (err) {
      lastError = err as Error;
      const msg = String((err as Error)?.message ?? err);
      const isRateLimit = msg.includes('429') || msg.toLowerCase().includes('too many requests');
      if (attempt < attempts) {
        // rate limits need long waits; other errors get short backoff
        const base = isRateLimit ? 8_000 : 1_000;
        const wait = Math.min(45_000, base * Math.pow(2, attempt - 1)) + Math.random() * 1_500;
        await sleep(wait);
      }
    } finally {
      release();
    }
  }
  throw lastError ?? new Error('LLM request failed');
}

function parseJsonLoose(raw: string): Record<string, string> | null {
  let s = raw.trim();
  s = s.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '');
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start === -1 || end === -1 || end <= start) return null;
  s = s.slice(start, end + 1);
  try {
    return JSON.parse(s) as Record<string, string>;
  } catch {
    try {
      return JSON.parse(s.replace(/,\s*([}\]])/g, '$1')) as Record<string, string>;
    } catch {
      return null;
    }
  }
}

/* ------------------------------------------------------------------ */
/* Passthrough rules                                                   */
/* ------------------------------------------------------------------ */

const RTL_RE = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
const ANY_LETTER_RE = /\p{L}/u;

export function needsTranslation(text: string, sourceIsTarget: boolean): boolean {
  const t = text.trim();
  if (t.length === 0) return false;
  if (!ANY_LETTER_RE.test(t)) return false; // pure numbers / punctuation / symbols
  if (sourceIsTarget) return false;         // document already in target language
  // standalone e-mail or URL
  if (/^(https?:\/\/\S+|[\w.+-]+@[\w-]+\.[\w.]+)$/i.test(t)) return false;
  // identifier-like single token (no spaces, short, contains digits)
  if (!/\s/.test(t) && t.length <= 24 && /^[A-Za-z0-9._\-/%:]+$/.test(t) && /\d/.test(t)) {
    return false;
  }
  return true;
}

/* ------------------------------------------------------------------ */
/* Language detection                                                  */
/* ------------------------------------------------------------------ */

const SCRIPT_HINTS: { re: RegExp; candidates: string }[] = [
  { re: RTL_RE, candidates: 'Pashto, Dari/Persian, Arabic, Urdu (look for Pashto-only letters: ټ ډ ړ ږ ښ ڼ ې ۍ; Urdu-only: ٹ ڈ ڑ ے)' },
  { re: /[\u4E00-\u9FFF]/, candidates: 'Chinese (Simplified or Traditional)' },
  { re: /[\u3040-\u30FF]/, candidates: 'Japanese' },
  { re: /[\uAC00-\uD7AF]/, candidates: 'Korean' },
  { re: /[\u0400-\u04FF]/, candidates: 'Russian or another Cyrillic language' },
  { re: /[\u0900-\u097F]/, candidates: 'Hindi or another Devanagari language' },
];

export async function detectLanguage(
  sampleText: string,
): Promise<{ code: string; name: string; confidence: string }> {
  const sample = sampleText.slice(0, 1500);
  if (sample.trim().length === 0) return { code: 'unknown', name: 'Unknown', confidence: 'low' };

  const scriptHint = SCRIPT_HINTS.find((h) => h.re.test(sample));
  const hintMsg = scriptHint
    ? ` The text uses a script suggesting one of: ${scriptHint.candidates}. Decide which language it actually is.`
    : '';

  const content = await chatWithRetry(
    [
      {
        role: 'assistant',
        content:
          'You are a language identification system. You reply with ONLY a JSON object, no explanations, no markdown.',
      },
      {
        role: 'user',
        content: `Identify the natural language of this text. Reply exactly as: {"code":"<ISO 639-1 code>","name":"<English language name>","confidence":"high|medium|low"}${hintMsg}\n\nTEXT:\n${sample}`,
      },
    ],
    2,
    60_000,
  );
  const parsed = parseJsonLoose(content);
  if (parsed && parsed.code && parsed.name) {
    return {
      code: String(parsed.code).slice(0, 8),
      name: String(parsed.name).slice(0, 40),
      confidence: String(parsed.confidence ?? 'medium'),
    };
  }
  return { code: 'unknown', name: 'Unknown', confidence: 'low' };
}

/* ------------------------------------------------------------------ */
/* Translation                                                         */
/* ------------------------------------------------------------------ */

export interface TranslateRunOptions {
  target: TargetLang;              // target language descriptor
  sourceLangName: string;          // detected source language name (or "Unknown")
  canceled?: () => boolean;
  onProgress?: (done: number, total: number) => void;
}
export interface TranslateRunResult {
  translations: Map<number, string>;
  warnings: string[];
  failed: number;
  batches: number;
}

const CHAR_BUDGET = 3200;
const MAX_SEGMENTS_PER_BATCH = 40;
const MAX_SINGLE_SEGMENT = 12_000;

function buildSystemPrompt(target: TargetLang, sourceName: string): string {
  return [
    `You are a professional document translator. You translate a ${sourceName} document into ${target.instruction}.`,
    `The segments come from one document (headings, paragraphs, table cells, captions, headers/footers, list items) in reading order.`,
    '',
    'STRICT RULES:',
    '1. Translate EVERY segment COMPLETELY. Never summarize, shorten, omit, or add content.',
    '2. Copy numbers, dates, times, currency amounts, percentages, phone numbers, e-mail addresses, URLs, file names, code and mathematical expressions EXACTLY as written.',
    '3. Keep person and organization names recognizable; use well-established translations where they exist.',
    '4. Keep terminology consistent across all segments (technical, legal, academic, business vocabulary).',
    '5. If a segment is already in the target language, output it unchanged.',
    '6. Table cells and captions may be fragments - translate them as natural fragments without inventing context.',
    '7. Do not add or remove quotation marks, bullets, or numbering markers at the start of a segment.',
    '8. Headings, titles and short fragments must read like natural, professional Pashto document phrases - not word-by-word translations.',
    '9. Respond with ONLY a valid JSON object mapping every id to its translation, e.g. {"12":"...","13":"..."}. No markdown fences, no commentary.',
    target.glossary ?? '',
  ]
    .filter(Boolean)
    .join('\n');
}

/** split an over-long segment into sentence chunks so nothing is lost */
function chunkLongSegment(text: string): string[] {
  if (text.length <= MAX_SINGLE_SEGMENT) return [text];
  const chunks: string[] = [];
  const sentences = text.split(/(?<=[.!?؟۔\n])\s+/);
  let cur = '';
  for (const s of sentences) {
    if ((cur + ' ' + s).length > MAX_SINGLE_SEGMENT) {
      if (cur) chunks.push(cur.trim());
      if (s.length > MAX_SINGLE_SEGMENT) {
        // hard-split pathological runs
        for (let i = 0; i < s.length; i += MAX_SINGLE_SEGMENT) {
          chunks.push(s.slice(i, i + MAX_SINGLE_SEGMENT));
        }
        cur = '';
      } else {
        cur = s;
      }
    } else {
      cur = cur ? cur + ' ' + s : s;
    }
  }
  if (cur.trim()) chunks.push(cur.trim());
  return chunks;
}

export async function translateSegments(
  segments: { id: number; text: string }[],
  opts: TranslateRunOptions,
): Promise<TranslateRunResult> {
  const translations = new Map<number, string>();
  const warnings: string[] = [];
  const target = opts.target;
  const sourceIsTarget = opts.sourceLangName.toLowerCase() === target.name.toLowerCase();

  // passthrough + dedup pass
  const cache = new Map<string, string>();
  const pending: { id: number; text: string }[] = [];
  let passthrough = 0;

  for (const seg of segments) {
    const trimmed = seg.text;
    if (!needsTranslation(trimmed, sourceIsTarget)) {
      translations.set(seg.id, trimmed);
      passthrough++;
      continue;
    }
    if (cache.has(trimmed)) {
      translations.set(seg.id, cache.get(trimmed)!);
      continue;
    }
    pending.push(seg);
  }

  // expand long segments into chunk work items
  const work: { key: number; text: string }[] = [];
  const chunkOwner = new Map<number, number[]>(); // segment id -> chunk keys
  for (const seg of pending) {
    const chunks = chunkLongSegment(seg.text);
    if (chunks.length === 1) {
      work.push({ key: seg.id, text: chunks[0] });
      chunkOwner.set(seg.id, [seg.id]);
    } else {
      const keys: number[] = [];
      for (let i = 0; i < chunks.length; i++) {
        const key = 1_000_000 + seg.id * 10 + i;
        work.push({ key, text: chunks[i] });
        keys.push(key);
      }
      chunkOwner.set(seg.id, keys);
    }
  }

  // batch in document order
  const batches: { key: number; text: string }[][] = [];
  let curBatch: { key: number; text: string }[] = [];
  let curChars = 0;
  for (const w of work) {
    if (curBatch.length >= MAX_SEGMENTS_PER_BATCH || curChars + w.text.length > CHAR_BUDGET) {
      if (curBatch.length > 0) batches.push(curBatch);
      curBatch = [];
      curChars = 0;
    }
    curBatch.push(w);
    curChars += w.text.length;
  }
  if (curBatch.length > 0) batches.push(curBatch);

  const systemPrompt = buildSystemPrompt(target, opts.sourceLangName || 'foreign-language');
  const total = work.length;
  let done = 0;
  let failedKeys: { key: number; text: string }[] = [];
  let batchIndex = 0;

  const runBatch = async (batch: { key: number; text: string }[]) => {
    if (opts.canceled?.()) return;
    const payload: Record<string, string> = {};
    for (const w of batch) payload[String(w.key)] = w.text;

    let parsed: Record<string, string> | null = null;
    try {
      const content = await chatWithRetry(
        [
          { role: 'assistant', content: systemPrompt },
          {
            role: 'user',
            content: `Translate each segment into ${target.name}. Return the JSON object with the same ids.\n\n${JSON.stringify(payload)}`,
          },
        ],
        6,
        150_000,
        () => opts.canceled?.() === true,
      );
      parsed = parseJsonLoose(content);
    } catch {
      parsed = null;
    }

    if (!parsed) {
      failedKeys.push(...batch);
    } else {
      for (const w of batch) {
        const tr = parsed[String(w.key)];
        if (typeof tr === 'string' && tr.trim().length > 0) {
          translations.set(w.key, tr);
          cache.set(w.text, tr);
        } else {
          failedKeys.push(w);
        }
      }
    }
    done += batch.length;
    opts.onProgress?.(done, total);
  };

  // limited parallelism (kept low: the shared AI gateway rate-limits hard)
  const PARALLEL = 2;
  const workers = Array.from({ length: Math.min(PARALLEL, batches.length) }, async () => {
    while (batchIndex < batches.length) {
      const i = batchIndex++;
      await runBatch(batches[i]);
    }
  });
  await Promise.all(workers);

  // one retry round for failed batches (smaller groups)
  if (failedKeys.length > 0 && !opts.canceled?.()) {
    const retry = failedKeys;
    failedKeys = [];
    for (let i = 0; i < retry.length; i += 10) {
      await runBatch(retry.slice(i, i + 10));
    }
  }

  // finalize: assemble chunked segments, fall back to original on failure
  for (const seg of pending) {
    const keys = chunkOwner.get(seg.id);
    if (!keys) continue;
    const parts = keys.map((k) => translations.get(k));
    if (parts.every((p) => typeof p === 'string')) {
      const joined = parts.join(' ');
      translations.set(seg.id, joined);
      cache.set(seg.text, joined);
    } else {
      translations.set(seg.id, seg.text); // keep original
      cache.set(seg.text, seg.text);
    }
  }

  if (failedKeys.length > 0) {
    warnings.push(
      `${failedKeys.length} text segment(s) could not be translated after retries and were kept in the original language.`,
    );
  }

  return {
    translations,
    warnings,
    failed: failedKeys.length,
    batches: batches.length,
  };
}
