/**
 * XLSX translation: replaces string cell values (shared strings + inline
 * strings) while keeping every formula, style, chart and sheet layout intact.
 */
import JSZip from 'jszip';
import {
  applySharedStrings,
  extractSharedStrings,
} from './ooxml';
import { DOMParser } from '@xmldom/xmldom';
import { descendantsByLocal, serializeXml, setLeafText, firstChildByLocal, childElements, localName } from './xml';
import type { SegmentTranslateFn } from './docx';

export interface TranslateXlsxOptions {
  onProgress?: (info: { phase: string; done?: number; total?: number }) => void;
}

interface SheetInline {
  name: string;
  doc: import('@xmldom/xmldom').Document;
  declaration: string;
  groups: { id: number; leaves: import('@xmldom/xmldom').Element[]; text: string }[];
}

export async function translateXlsx(
  input: Buffer,
  translate: SegmentTranslateFn,
  opts: TranslateXlsxOptions = {},
): Promise<{ output: Buffer; segmentCount: number }> {
  const zip = await JSZip.loadAsync(input);
  let nextId = 0;
  let segmentCount = 0;

  // --- shared strings -------------------------------------------------
  const sharedFile = zip.file('xl/sharedStrings.xml');
  let sharedResult: ReturnType<typeof extractSharedStrings> | null = null;
  if (sharedFile) {
    const xml = await sharedFile.async('string');
    sharedResult = extractSharedStrings(xml, nextId);
    nextId = sharedResult.nextId;
  }

  // --- inline strings in worksheets ------------------------------------
  const sheetNames: string[] = [];
  zip.forEach((p, f) => {
    if (!f.dir && /^xl\/worksheets\/sheet\d+\.xml$/.test(p)) sheetNames.push(p);
  });
  sheetNames.sort();
  const sheetStates: SheetInline[] = [];
  for (const name of sheetNames) {
    const xml = await zip.file(name)!.async('string');
    const doc = new DOMParser({ onError: () => undefined }).parseFromString(xml, 'text/xml');
    const declaration = xml.match(/^\s*<\?xml[^>]*\?>/)?.[0] ?? '';
    const groups: SheetInline['groups'] = [];
    for (const is of descendantsByLocal(doc, ['is'])) {
      const leaves = descendantsByLocal(is, ['t']);
      const text = leaves.map((t) => t.textContent ?? '').join('');
      if (text.trim().length === 0) continue;
      groups.push({ id: nextId++, leaves, text });
    }
    sheetStates.push({ name, doc, declaration, groups });
  }

  const segments: { id: number; text: string }[] = [];
  if (sharedResult) {
    for (const item of sharedResult.items) segments.push({ id: item.segmentId, text: item.text });
  }
  for (const s of sheetStates) {
    for (const g of s.groups) segments.push({ id: g.id, text: g.text });
  }
  segmentCount = segments.length;

  opts.onProgress?.({ phase: 'translate', done: 0, total: segmentCount });
  const translations = await translate(segments, (done, total) => {
    opts.onProgress?.({ phase: 'translate', done, total });
  });

  opts.onProgress?.({ phase: 'rebuild' });
  if (sharedResult) {
    applySharedStrings(sharedResult.items, translations);
    zip.file('xl/sharedStrings.xml', serializeXml(sharedResult.doc, sharedResult.declaration));
  }
  for (const s of sheetStates) {
    let changed = false;
    for (const g of s.groups) {
      const tr = translations.get(g.id);
      if (tr === undefined) continue;
      setLeafText(g.leaves[0], tr);
      for (let i = 1; i < g.leaves.length; i++) setLeafText(g.leaves[i], '');
      changed = true;
    }
    if (changed) zip.file(s.name, serializeXml(s.doc, s.declaration));
  }

  const output = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  return { output, segmentCount };
}

/** Read sheet structure for the .docx reading rendition (after translation) */
export async function xlsxSheetTexts(input: Buffer): Promise<{ name: string; rows: string[] }[]> {
  const zip = await JSZip.loadAsync(input);
  const out: { name: string; rows: string[] }[] = [];
  const workbookXml = zip.file('xl/workbook.xml');
  let sheetNames: string[] = [];
  if (workbookXml) {
    const wb = new DOMParser({ onError: () => undefined }).parseFromString(await workbookXml.async('string'), 'text/xml');
    sheetNames = descendantsByLocal(wb, ['sheet'])
      .map((s) => s.getAttribute('name') ?? '')
      .filter(Boolean);
  }
  const names: string[] = [];
  zip.forEach((p, f) => {
    if (!f.dir && /^xl\/worksheets\/sheet\d+\.xml$/.test(p)) names.push(p);
  });
  names.sort();

  const loadStrings = async (): Promise<Map<number, string>> => {
    const map = new Map<number, string>();
    const ss = zip.file('xl/sharedStrings.xml');
    if (!ss) return map;
    const doc = new DOMParser({ onError: () => undefined }).parseFromString(await ss.async('string'), 'text/xml');
    const sis = descendantsByLocal(doc, ['si']);
    sis.forEach((si, i) => {
      map.set(i, descendantsByLocal(si, ['t']).map((t) => t.textContent ?? '').join(''));
    });
    return map;
  };
  const strings = await loadStrings();

  for (let i = 0; i < names.length; i++) {
    const xml = await zip.file(names[i])!.async('string');
    const doc = new DOMParser({ onError: () => undefined }).parseFromString(xml, 'text/xml');
    const rows: string[] = [];
    for (const row of descendantsByLocal(doc, ['row'])) {
      const cells: string[] = [];
      for (const c of childElements(row)) {
        if (localName(c) !== 'c') continue;
        const type = c.getAttribute('t');
        if (type === 's') {
          const v = firstChildByLocal(c, 'v');
          const idx = v?.textContent ? parseInt(v.textContent, 10) : NaN;
          cells.push(!isNaN(idx) ? strings.get(idx) ?? '' : '');
        } else if (type === 'inlineStr') {
          const is = firstChildByLocal(c, 'is');
          cells.push(is ? descendantsByLocal(is, ['t']).map((t) => t.textContent ?? '').join('') : '');
        } else {
          const v = firstChildByLocal(c, 'v');
          cells.push(v?.textContent ?? '');
        }
      }
      if (cells.some((v) => v.trim().length > 0)) rows.push(cells.join('   |   '));
    }
    out.push({ name: sheetNames[i] ?? `Sheet ${i + 1}`, rows });
  }
  return out;
}
