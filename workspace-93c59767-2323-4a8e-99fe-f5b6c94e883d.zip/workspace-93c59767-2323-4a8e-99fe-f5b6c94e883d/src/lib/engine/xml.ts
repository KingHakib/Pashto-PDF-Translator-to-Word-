/**
 * XML utilities for OOXML (docx/pptx/xlsx) in-place text surgery.
 *
 * The key idea: a document is a ZIP of XML parts. We parse each part,
 * collect the text leaf nodes (<w:t> in Word, <a:t> in PowerPoint) grouped by
 * their nearest paragraph ancestor, translate the paragraph text, and write it
 * back into the FIRST text leaf while emptying the others. Every other node
 * (styles, tables, images, drawing anchors, sectPr...) is left untouched, so
 * the original layout survives 1:1.
 *
 * Insertion of new elements (bidi, rtl, cs fonts) must follow the OOXML schema
 * child order, otherwise Microsoft Word shows a "repair" dialog. We therefore
 * insert using explicit rank tables.
 */
import {
  DOMParser,
  XMLSerializer,
  type Document,
  type Element,
  type Node,
} from '@xmldom/xmldom';

export const W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
export const A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main';

/** Order of children of <w:pPr> per ECMA-376 schema */
export const W_PPR_ORDER = [
  'pStyle', 'keepNext', 'keepLines', 'pageBreakBefore', 'framePr', 'widowControl',
  'numPr', 'suppressLineNumbers', 'pBdr', 'shd', 'tabs', 'suppressAutoHyphens',
  'kinsoku', 'wordWrap', 'overflowPunct', 'topLinePunct', 'autoSpaceDE',
  'autoSpaceDN', 'bidi', 'adjustRightInd', 'snapToGrid', 'spacing', 'ind',
  'contextualSpacing', 'mirrorIndents', 'suppressOverlap', 'jc', 'textDirection',
  'textAlignment', 'textboxTightWrap', 'outlineLvl', 'divId', 'cnfStyle', 'rPr',
  'sectPr', 'pPrChange',
];

/** Order of children of <w:rPr> per ECMA-376 schema */
export const W_RPR_ORDER = [
  'rStyle', 'rFonts', 'b', 'bCs', 'i', 'iCs', 'caps', 'smallCaps', 'strike',
  'dstrike', 'outline', 'shadow', 'emboss', 'imprint', 'noProof', 'snapToGrid',
  'vanish', 'webHidden', 'color', 'spacing', 'w', 'kern', 'position', 'sz',
  'szCs', 'highlight', 'u', 'effect', 'bdr', 'shd', 'fitText', 'vertAlign',
  'rtl', 'cs', 'em', 'lang', 'eastAsianLayout', 'specVanish', 'oMath',
];

/** Order of children of <a:rPr> (DrawingML) */
export const A_RPR_ORDER = [
  'ln', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill',
  'effectLst', 'effectDag', 'highlight', 'uLnTx', 'uLn', 'uFillTx', 'uFill',
  'latin', 'ea', 'cs', 'sym', 'hlinkClick', 'hlinkMouseOver', 'rtl', 'extLst',
];

export function parseXml(xml: string): Document {
  const parser = new DOMParser({
    onError: () => {
      /* non-fatal issues are tolerated; fatal errors throw natively */
    },
  });
  return parser.parseFromString(xml, 'text/xml');
}

export function extractXmlDeclaration(xml: string): string {
  const m = xml.match(/^\s*<\?xml[^>]*\?>/);
  return m ? m[0] : '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
}

export function serializeXml(doc: Document, declaration?: string): string {
  const body = new XMLSerializer().serializeToString(doc);
  const stripped = body.replace(/^\s*<\?xml[^>]*\?>\s*/, '');
  return (declaration ?? '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>') + stripped;
}

export function localName(el: Node): string {
  const name = el.nodeName || '';
  const idx = name.indexOf(':');
  return idx >= 0 ? name.slice(idx + 1) : name;
}

export function childElements(el: Node): Element[] {
  const out: Element[] = [];
  let child = el.firstChild;
  while (child) {
    if (child.nodeType === 1) out.push(child as Element);
    child = child.nextSibling;
  }
  return out;
}

export function firstChildByLocal(el: Node, name: string): Element | null {
  for (const c of childElements(el)) {
    if (localName(c) === name) return c;
  }
  return null;
}

/** Depth-first document-order collection of elements with a given local name */
export function descendantsByLocal(root: Node, names: string[]): Element[] {
  const set = new Set(names);
  const out: Element[] = [];
  const walk = (node: Node) => {
    let child = node.firstChild;
    while (child) {
      if (child.nodeType === 1) {
        if (set.has(localName(child))) out.push(child as Element);
        walk(child);
      }
      child = child.nextSibling;
    }
  };
  walk(root);
  return out;
}

export function insertOrdered(parent: Element, el: Element, order: string[]): void {
  const rank = order.indexOf(localName(el));
  for (const child of childElements(parent)) {
    const r = order.indexOf(localName(child));
    if (r !== -1 && r > rank) {
      parent.insertBefore(el, child);
      return;
    }
  }
  parent.appendChild(el);
}

/** Find direct child by localName, creating it (in schema position) if missing */
export function ensureChild(
  parent: Element,
  name: string,
  ns: string,
  prefix: string,
  order: string[],
): Element {
  const existing = firstChildByLocal(parent, name);
  if (existing) return existing;
  const el = parent.ownerDocument!.createElementNS(ns, `${prefix}:${name}`);
  insertOrdered(parent, el, order);
  return el;
}

/** Nearest ancestor whose local name is in `names` */
export function nearestAncestor(node: Node, names: string[]): Element | null {
  let cur: Node | null = node.parentNode;
  while (cur) {
    if (cur.nodeType === 1 && names.includes(localName(cur))) return cur as Element;
    cur = cur.parentNode;
  }
  return null;
}

export function setLeafText(el: Element, text: string): void {
  // Remove all children, then set a single text node
  while (el.firstChild) el.removeChild(el.firstChild);
  if (text.length > 0) {
    el.setAttribute('xml:space', 'preserve');
    el.appendChild(el.ownerDocument!.createTextNode(text));
  } else {
    el.removeAttribute('xml:space');
  }
}

/** Arabic / RTL script detection (covers Arabic, Pashto, Persian, Urdu...) */
export function hasRtlScript(text: string): boolean {
  return /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text);
}
