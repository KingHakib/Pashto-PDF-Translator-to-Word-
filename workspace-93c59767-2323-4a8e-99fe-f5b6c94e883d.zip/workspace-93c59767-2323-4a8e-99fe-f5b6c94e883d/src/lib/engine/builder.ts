/**
 * Minimal, valid DOCX builder for Pashto/RTL text flow documents.
 * Used for: TXT input, OCR output of scanned PDFs, and the Word "reading
 * rendition" of PPTX/XLSX sources. Produces clean WordprocessingML with
 * bidi paragraphs, complex-script fonts and correct schema ordering.
 */

export interface BuilderBlock {
  type: 'heading' | 'para';
  text: string;
  level?: 1 | 2 | 3;
  pageBreakBefore?: boolean;
  center?: boolean;
  muted?: boolean;
}

const CS_FONT = 'Tahoma';
const LATIN_FONT = 'Calibri';

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function runXml(text: string, bold: boolean, sizeHalf: number, color?: string): string {
  const rpr = [
    `<w:rFonts w:ascii="${LATIN_FONT}" w:hAnsi="${LATIN_FONT}" w:cs="${CS_FONT}"/>`,
    bold ? '<w:b/><w:bCs/>' : '',
    color ? `<w:color w:val="${color}"/>` : '',
    `<w:sz w:val="${sizeHalf}"/><w:szCs w:val="${sizeHalf}"/>`,
    '<w:rtl/>',
    '<w:lang w:bidi="ps-AF"/>',
  ].join('');
  return `<w:r><w:rPr>${rpr}</w:rPr><w:t xml:space="preserve">${esc(text)}</w:t></w:r>`;
}

function blockXml(block: BuilderBlock): string {
  if (block.pageBreakBefore) {
    // page break is its own paragraph
  }
  const sizes = { 1: 36, 2: 30, 3: 26 } as const;
  const colors = { 1: '1B5E20', 2: '2E7D32', 3: '33691E' } as const;
  const beforeAfter =
    block.type === 'heading'
      ? `<w:spacing w:before="280" w:after="140"/>`
      : `<w:spacing w:after="140" w:line="276" w:lineRule="auto"/>`;

  const parts: string[] = [];
  if (block.pageBreakBefore) {
    parts.push(
      `<w:p><w:pPr><w:bidi/></w:pPr><w:r><w:br w:type="page"/></w:r></w:p>`,
    );
  }
  const ppr = [
    block.type === 'heading' ? `<w:pStyle w:val="Heading${block.level ?? 1}"/>` : '',
    '<w:bidi/>',
    beforeAfter,
    block.center ? '<w:jc w:val="center"/>' : '',
  ].join('');

  if (block.type === 'heading') {
    const level = (block.level ?? 1) as 1 | 2 | 3;
    parts.push(
      `<w:p><w:pPr>${ppr}</w:pPr>${runXml(block.text, true, sizes[level], block.muted ? undefined : colors[level])}</w:p>`,
    );
  } else {
    parts.push(`<w:p><w:pPr>${ppr}</w:pPr>${runXml(block.text, false, 24)}</w:p>`);
  }
  return parts.join('');
}

const CONTENT_TYPES = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>`;

const ROOT_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`;

const DOC_RELS = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`;

function stylesXml(): string {
  const headingStyle = (id: number, size: number) =>
    `<w:style w:type="paragraph" w:styleId="Heading${id}"><w:name w:val="heading ${id}"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="${id - 1}"/></w:pPr><w:rPr><w:rFonts w:ascii="${LATIN_FONT}" w:hAnsi="${LATIN_FONT}" w:cs="${CS_FONT}"/><w:b/><w:bCs/><w:sz w:val="${size}"/><w:szCs w:val="${size}"/></w:rPr></w:style>`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="${LATIN_FONT}" w:hAnsi="${LATIN_FONT}" w:cs="${CS_FONT}"/><w:sz w:val="24"/><w:szCs w:val="24"/><w:lang w:val="en-US" w:bidi="ps-AF"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:pPr><w:bidi/><w:spacing w:after="140" w:line="276" w:lineRule="auto"/></w:pPr></w:style>${headingStyle(1, 36)}${headingStyle(2, 30)}${headingStyle(3, 26)}</w:styles>`;
}

export async function buildRtlDocx(pages: BuilderBlock[][]): Promise<Buffer> {
  const flat = pages.flat();
  // auto page-break between pages
  const bodyBlocks: BuilderBlock[] = [];
  flat.forEach((b, i) => {
    const isFirstOfPage = pages.some((p) => p.length > 0 && p[0] === b);
    bodyBlocks.push({ ...b, pageBreakBefore: isFirstOfPage && i > 0 });
  });

  const body = bodyBlocks.map(blockXml).join('');
  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}<w:sectPr><w:bidi/><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`;

  const JSZip = (await import('jszip')).default;
  const zip = new JSZip();
  zip.file('[Content_Types].xml', CONTENT_TYPES);
  zip.file('_rels/.rels', ROOT_RELS);
  zip.file('word/document.xml', documentXml);
  zip.file('word/_rels/document.xml.rels', DOC_RELS);
  zip.file('word/styles.xml', stylesXml());
  return zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
}

/** Convenience: one flow of paragraphs (txt files) */
export function flowToPages(lines: string[], perPageSoftLimit = 40): BuilderBlock[][] {
  const pages: BuilderBlock[][] = [[]];
  let count = 0;
  for (const line of lines) {
    if (count >= perPageSoftLimit) {
      pages.push([]);
      count = 0;
    }
    pages[pages.length - 1].push({ type: 'para', text: line });
    count++;
  }
  return pages;
}
