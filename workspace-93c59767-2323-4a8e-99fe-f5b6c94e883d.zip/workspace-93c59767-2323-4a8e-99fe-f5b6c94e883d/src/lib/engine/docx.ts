/**
 * DOCX translation with full format preservation.
 *
 * Strategy: operate on the OOXML zip directly. Translate the text inside
 * word/document.xml + headers + footers + footnotes + endnotes + comments +
 * charts while leaving every styling/layout node untouched, then apply RTL
 * paragraph direction to the translated paragraphs only.
 */
import JSZip from 'jszip';
import {
  applyDocxRtl,
  applyTranslations,
  extractGroupsFromPart,
  type OoxmlGroup,
} from './ooxml';
import { serializeXml } from './xml';

export type SegmentTranslateFn = (
  segments: { id: number; text: string }[],
  onProgress?: (done: number, total: number) => void,
) => Promise<Map<number, string>>;

export interface TranslateDocxOptions {
  targetRtl: boolean;
  langBidi: string;   // e.g. "ps-AF"
  csFont: string;     // e.g. "Tahoma"
  onProgress?: (info: { phase: string; done?: number; total?: number }) => void;
}

interface PartState {
  name: string;
  doc: import('@xmldom/xmldom').Document;
  declaration: string;
  groups: OoxmlGroup[];
}

function isWordTextPart(name: string): boolean {
  if (name === 'word/document.xml') return true;
  if (/^word\/header\d*\.xml$/.test(name)) return true;
  if (/^word\/footer\d*\.xml$/.test(name)) return true;
  if (name === 'word/footnotes.xml') return true;
  if (name === 'word/endnotes.xml') return true;
  if (name === 'word/comments.xml') return true;
  if (/^word\/charts\/chart\d*\.xml$/.test(name)) return true;
  return false;
}

export async function translateDocx(
  input: Buffer,
  translate: SegmentTranslateFn,
  opts: TranslateDocxOptions,
): Promise<{ output: Buffer; segmentCount: number }> {
  const zip = await JSZip.loadAsync(input);

  // 1. Collect text parts
  const partNames: string[] = [];
  zip.forEach((relativePath, file) => {
    if (!file.dir && isWordTextPart(relativePath)) partNames.push(relativePath);
  });
  partNames.sort((a, b) => {
    // document first, then headers/footers/notes alphabetically
    const ra = a === 'word/document.xml' ? 0 : 1;
    const rb = b === 'word/document.xml' ? 0 : 1;
    if (ra !== rb) return ra - rb;
    return a.localeCompare(b);
  });
  if (!partNames.includes('word/document.xml')) {
    throw new Error('Not a valid Word document (word/document.xml missing)');
  }

  // 2. Parse parts and extract paragraph groups
  opts.onProgress?.({ phase: 'extract' });
  const states: PartState[] = [];
  let nextId = 0;
  for (const name of partNames) {
    const xml = await zip.file(name)!.async('string');
    const { groups, doc, declaration } = extractGroupsFromPart(name, xml, 'w', nextId);
    nextId += groups.length;
    states.push({ name, doc, declaration, groups });
  }

  const allGroups = states.flatMap((s) => s.groups);
  const segments = allGroups
    .filter((g) => g.text.trim().length > 0)
    .map((g) => ({ id: g.id, text: g.text }));
  const segmentCount = segments.length;

  // 3. Translate (LLM with batching, progress reported from inside)
  opts.onProgress?.({ phase: 'translate', done: 0, total: segmentCount });
  const translations = await translate(segments, (done, total) => {
    opts.onProgress?.({ phase: 'translate', done, total });
  });

  // 4. Write back + RTL
  opts.onProgress?.({ phase: 'rebuild' });
  for (const state of states) {
    applyTranslations(state.groups, translations);
    if (opts.targetRtl) {
      applyDocxRtl(state.groups, translations, opts.langBidi, opts.csFont);
    }
    const outXml = serializeXml(state.doc, state.declaration);
    zip.file(state.name, outXml);
  }

  // 5. Repack
  const output = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  return { output, segmentCount };
}

/** Count text segments without translating (used for previews/stats) */
export async function countDocxSegments(input: Buffer): Promise<number> {
  const zip = await JSZip.loadAsync(input);
  let count = 0;
  let nextId = 0;
  return new Promise((resolve, reject) => {
    const names: string[] = [];
    zip.forEach((p, f) => {
      if (!f.dir && isWordTextPart(p)) names.push(p);
    });
    (async () => {
      for (const name of names) {
        const xml = await zip.file(name)!.async('string');
        const { groups } = extractGroupsFromPart(name, xml, 'w', nextId);
        nextId += groups.length;
        count += groups.filter((g) => g.text.trim().length > 0).length;
      }
      resolve(count);
    })().catch(reject);
  });
}
