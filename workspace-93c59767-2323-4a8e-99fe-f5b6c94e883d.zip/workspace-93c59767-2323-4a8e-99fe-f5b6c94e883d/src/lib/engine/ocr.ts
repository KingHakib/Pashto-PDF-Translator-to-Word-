/**
 * OCR pipeline for scanned PDFs.
 * 1. Render pages to 300dpi PNG (pdftoppm)
 * 2. Detect the script of the document (tesseract OSD)
 * 3. OCR each page with the right language pack(s) and keep paragraph
 *    structure from tesseract's TSV output (block/paragraph grouping)
 */
import fs from 'fs';
import path from 'path';
import { run } from './convert';

export interface OcrParagraph {
  text: string;
  confidence: number;
}

export interface OcrPage {
  page: number;
  paragraphs: OcrParagraph[];
}

const SCRIPT_LANGS: Record<string, string> = {
  Latin: 'eng',
  Arabic: 'pus+ara+fas',
  Han: 'chi_sim',
  Cyrillic: 'rus',
  Devanagari: 'hin',
  Japanese: 'chi_sim',
  Korean: 'chi_sim',
  Fraktur: 'deu',
};

export function detectScriptLang(script: string): string {
  return SCRIPT_LANGS[script] ?? 'eng';
}

async function detectScript(pageImage: string): Promise<string> {
  const res = await run('tesseract', [pageImage, 'stdout', '--psm', '0'], { timeoutMs: 60_000 });
  const m = res.stdout.match(/Script:\s*([A-Za-z]+)/);
  return m ? m[1] : 'Latin';
}

export async function ocrPdf(
  pdfPath: string,
  workDir: string,
  maxPages: number,
  onProgress?: (done: number, total: number) => void,
): Promise<{ pages: OcrPage[]; scripts: string[]; langUsed: string }> {
  fs.mkdirSync(workDir, { recursive: true });

  const render = await run(
    'pdftoppm',
    ['-r', '300', '-png', '-l', String(maxPages), pdfPath, path.join(workDir, 'page')],
    { timeoutMs: 600_000 },
  );
  if (render.code !== 0) throw new Error('Failed to render PDF pages for OCR');
  const images = fs
    .readdirSync(workDir)
    .filter((f) => /^page-\d+\.png$/.test(f))
    .sort((a, b) => parseInt(a.match(/\d+/)![0], 10) - parseInt(b.match(/\d+/)![0], 10))
    .map((f) => path.join(workDir, f));
  if (images.length === 0) throw new Error('No pages could be rendered from the PDF');

  const script = await detectScript(images[0]);
  const langs = detectScriptLang(script);

  const pages: OcrPage[] = [];
  for (let i = 0; i < images.length; i++) {
    const img = images[i];
    const base = path.join(workDir, `ocr-${i}`);
    const res = await run('tesseract', [img, base, '-l', langs, '--psm', '3', 'tsv'], {
      timeoutMs: 300_000,
    });
    const page: OcrPage = { page: i + 1, paragraphs: [] };
    if (res.code === 0 && fs.existsSync(`${base}.tsv`)) {
      page.paragraphs = parseTsv(`${base}.tsv`, script === 'Han' || script === 'Japanese');
    }
    pages.push(page);
    onProgress?.(i + 1, images.length);
  }

  // clean rendered page images (they are large)
  for (const img of images) {
    try { fs.unlinkSync(img); } catch { /* ignore */ }
  }

  return { pages, scripts: [script], langUsed: langs };
}

function parseTsv(tsvPath: string, joinWithoutSpaces: boolean): OcrParagraph[] {
  const content = fs.readFileSync(tsvPath, 'utf-8');
  const lines = content.split('\n').filter(Boolean);
  type Word = { text: string; conf: number };
  const paragraphs = new Map<string, { words: Word[]; key: string; order: number }>();
  let order = 0;
  for (const line of lines.slice(1)) {
    const cols = line.split('\t');
    if (cols.length < 12) continue;
    const level = parseInt(cols[0], 10);
    if (level !== 5) continue; // word level
    const blockNum = cols[2];
    const parNum = cols[3];
    const conf = parseFloat(cols[10]);
    const text = cols[11];
    if (!text || text.trim().length === 0) continue;
    const key = `${blockNum}:${parNum}`;
    if (!paragraphs.has(key)) paragraphs.set(key, { words: [], key, order: order++ });
    paragraphs.get(key)!.words.push({ text, conf: isNaN(conf) ? -1 : conf });
  }

  const result: OcrParagraph[] = [];
  for (const p of [...paragraphs.values()].sort((a, b) => a.order - b.order)) {
    const words = p.words;
    const joined = words.map((w) => w.text).join(joinWithoutSpaces ? '' : ' ').trim();
    if (!joined) continue;
    const valid = words.filter((w) => w.conf >= 0);
    const confidence = valid.length
      ? valid.reduce((s, w) => s + w.conf, 0) / valid.length
      : 0;
    result.push({ text: joined, confidence });
  }
  return result;
}
