/**
 * Wrappers around LibreOffice (soffice), Poppler (pdftotext/pdftoppm/pdfinfo)
 * and tesseract. All external processes get a controlled environment:
 *  - FONTCONFIG_FILE: makes project-local Pashto/Arabic fonts visible and
 *    maps "Tahoma"/"Arial"/"Times New Roman" to proper Arabic-script fonts
 *    so PDF export renders Pashto correctly.
 *  - TESSDATA_PREFIX: project-local OCR language packs.
 *  - HOME/UserInstallation: writable, per-invocation LibreOffice profile
 *    (soffice cannot run concurrent conversions in one shared profile).
 */
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

export const ASSETS_DIR = path.join(process.cwd(), 'assets');
export const FONTCONFIG_FILE = path.join(ASSETS_DIR, 'fonts.conf');
export const TESSDATA_PREFIX = path.join(ASSETS_DIR, 'tessdata');

export const CHILD_ENV: NodeJS.ProcessEnv = {
  ...process.env,
  FONTCONFIG_FILE,
  TESSDATA_PREFIX,
};

/* ---------------- process runner ---------------- */

export interface RunResult {
  code: number;
  stdout: string;
  stderr: string;
  timedOut: boolean;
}

export function run(
  cmd: string,
  args: string[],
  opts: { timeoutMs?: number; env?: NodeJS.ProcessEnv; cwd?: string } = {},
): Promise<RunResult> {
  const timeoutMs = opts.timeoutMs ?? 180_000;
  return new Promise((resolve) => {
    let settled = false;
    let stdout = '';
    let stderr = '';
    let timedOut = false;
    let child: ReturnType<typeof spawn>;
    try {
      // detached:true creates a process group so we can kill soffice.bin etc.
      child = spawn(cmd, args, {
        env: opts.env ?? CHILD_ENV,
        cwd: opts.cwd,
        stdio: ['ignore', 'pipe', 'pipe'],
        detached: true,
      });
    } catch (err) {
      resolve({ code: -1, stdout: '', stderr: String(err), timedOut: false });
      return;
    }
    const finish = (code: number) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve({ code, stdout, stderr, timedOut });
    };
    const timer = setTimeout(() => {
      timedOut = true;
      try {
        if (child.pid) process.kill(-child.pid, 'SIGKILL'); // kill whole group
      } catch {
        try { child.kill('SIGKILL'); } catch { /* already dead */ }
      }
    }, timeoutMs);
    child.stdout.on('data', (d) => {
      stdout += d.toString();
      if (stdout.length > 4_000_000) stdout = stdout.slice(0, 4_000_000);
    });
    child.stderr.on('data', (d) => {
      stderr += d.toString();
      if (stderr.length > 1_000_000) stderr = stderr.slice(0, 1_000_000);
    });
    child.on('error', (err) => {
      finish(-1);
      void err;
    });
    // 'exit' fires when the process dies; 'close' waits for stdio pipes which
    // orphaned children (soffice.bin) can keep open - so fall back to 'exit'.
    child.on('exit', (code) => {
      setTimeout(() => finish(code ?? -1), 1_500);
    });
    child.on('close', (code) => finish(code ?? -1));
  });
}

/* ---------------- soffice (mutex) ---------------- */

let sofficeQueue: Promise<unknown> = Promise.resolve();

/** soffice conversions are serialized: one shared profile would deadlock.
    A hard cap guarantees a hung conversion can never poison the chain. */
export function withSofficeLock<T>(fn: () => Promise<T>, hardCapMs = 420_000): Promise<T> {
  const guarded = async (): Promise<T> => {
    return await Promise.race([
      fn(),
      new Promise<T>((_, reject) =>
        setTimeout(() => reject(new Error('soffice hard timeout')), hardCapMs),
      ),
    ]);
  };
  const run2 = sofficeQueue.then(guarded, guarded);
  sofficeQueue = run2.catch(() => undefined);
  return run2;
}

export type SofficeTarget = 'docx' | 'pdf' | 'pptx' | 'xlsx';

export async function sofficeConvert(
  input: string,
  outDir: string,
  target: SofficeTarget,
  profileDir: string,
  timeoutMs = 240_000,
): Promise<{ ok: boolean; output?: string; log: string }> {
  return withSofficeLock(async () => {
    fs.mkdirSync(profileDir, { recursive: true });
    fs.mkdirSync(outDir, { recursive: true });
    // HTML input needs an explicit Writer export filter
    const inputExt = path.extname(input).toLowerCase();
    const convertArg =
      target === 'docx' && (inputExt === '.html' || inputExt === '.htm')
        ? 'docx:MS Word 2007 XML'
        : target;
    const res = await run(
      'soffice',
      [
        `-env:UserInstallation=file://${profileDir}`,
        '--headless',
        '--norestore',
        '--nolockcheck',
        '--convert-to',
        convertArg,
        '--outdir',
        outDir,
        input,
      ],
      { timeoutMs },
    );
    const base = path.basename(input).replace(/\.[^.]+$/, '');
    const output = path.join(outDir, `${base}.${target}`);
    if (res.code === 0 && fs.existsSync(output)) return { ok: true, output, log: res.stderr };
    return { ok: false, log: `${res.stderr}\n${res.stdout}`.trim() };
  });
}

/* ---------------- poppler ---------------- */

export async function pdfPageCount(file: string): Promise<number> {
  const res = await run('pdfinfo', [file], { timeoutMs: 30_000 });
  const m = res.stdout.match(/Pages:\s+(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}

export async function pdfExtractText(
  file: string,
  firstPage?: number,
  lastPage?: number,
): Promise<string> {
  const args = [file];
  if (firstPage) args.push('-f', String(firstPage));
  if (lastPage) args.push('-l', String(lastPage));
  args.push('-');
  const res = await run('pdftotext', args, { timeoutMs: 120_000 });
  return res.stdout;
}

export async function renderPdfPages(
  pdfPath: string,
  outDir: string,
  prefix: string,
  opts: { pages?: number; dpi?: number; format?: 'jpeg' | 'png' } = {},
): Promise<string[]> {
  fs.mkdirSync(outDir, { recursive: true });
  const dpi = opts.dpi ?? 90;
  const format = opts.format ?? 'jpeg';
  const args = [
    '-r', String(dpi),
    `-${format}`,
    '-jpegopt', 'quality=82',
  ];
  if (opts.pages) args.push('-l', String(opts.pages));
  args.push(pdfPath, path.join(outDir, prefix));
  const res = await run('pdftoppm', args, { timeoutMs: 180_000 });
  if (res.code !== 0) return [];
  const files = fs
    .readdirSync(outDir)
    .filter((f) => f.startsWith(prefix) && (f.endsWith('.jpg') || f.endsWith('.png')))
    .sort()
    .map((f) => path.join(outDir, f));
  return files;
}

/* ---------------- shared process helpers ---------------- */

export function fileMagic(buf: Buffer): 'zip' | 'ole' | 'pdf' | 'text' | 'rtf' | 'unknown' {
  if (buf.length >= 4 && buf[0] === 0x50 && buf[1] === 0x4b) return 'zip';
  if (buf.length >= 8 && buf[0] === 0xd0 && buf[1] === 0xcf) return 'ole';
  if (buf.slice(0, 5).toString('ascii') === '%PDF-') return 'pdf';
  if (buf.slice(0, 6).toString('ascii').toUpperCase().startsWith('{\\RTF')) return 'rtf';
  if (buf.slice(0, 512).some((b) => b === 0)) return 'unknown';
  return 'text';
}
