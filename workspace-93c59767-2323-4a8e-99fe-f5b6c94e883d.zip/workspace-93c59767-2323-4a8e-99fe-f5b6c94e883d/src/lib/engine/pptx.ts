/**
 * PPTX translation with full format preservation (slides, notes, charts,
 * SmartArt diagrams). Text is replaced in place inside <a:t> leaves; RTL
 * paragraph direction is applied to translated paragraphs.
 */
import JSZip from 'jszip';
import {
  applyPptxRtl,
  applyTranslations,
  extractGroupsFromPart,
  type OoxmlGroup,
} from './ooxml';
import { serializeXml } from './xml';
import type { SegmentTranslateFn } from './docx';

export interface TranslatePptxOptions {
  targetRtl: boolean;
  langTag: string;  // e.g. "ps-AF"
  csFont: string;   // e.g. "Tahoma"
  onProgress?: (info: { phase: string; done?: number; total?: number }) => void;
}

interface PartState {
  name: string;
  doc: import('@xmldom/xmldom').Document;
  declaration: string;
  groups: OoxmlGroup[];
  order: number;
}

function slideOrder(name: string): number {
  // slides first (numeric order), then notes, then charts/diagrams
  const num = (re: RegExp) => {
    const m = name.match(re);
    return m ? parseInt(m[1], 10) : Number.MAX_SAFE_INTEGER;
  };
  if (/^ppt\/slides\/slide(\d+)\.xml$/.test(name)) return num(/^ppt\/slides\/slide(\d+)\.xml$/);
  if (/^ppt\/notesSlides\/notesSlide(\d+)\.xml$/.test(name))
    return 100000 + num(/^ppt\/notesSlides\/notesSlide(\d+)\.xml$/);
  return 200000;
}

function isPptxTextPart(name: string): boolean {
  if (/^ppt\/slides\/slide\d+\.xml$/.test(name)) return true;
  if (/^ppt\/notesSlides\/notesSlide\d+\.xml$/.test(name)) return true;
  if (/^ppt\/charts\/chart\d+\.xml$/.test(name)) return true;
  if (/^ppt\/diagrams\/data\d+\.xml$/.test(name)) return true;
  return false;
}

export async function translatePptx(
  input: Buffer,
  translate: SegmentTranslateFn,
  opts: TranslatePptxOptions,
): Promise<{ output: Buffer; segmentCount: number }> {
  const zip = await JSZip.loadAsync(input);
  const partNames: string[] = [];
  zip.forEach((relativePath, file) => {
    if (!file.dir && isPptxTextPart(relativePath)) partNames.push(relativePath);
  });
  partNames.sort((a, b) => slideOrder(a) - slideOrder(b));
  if (!partNames.some((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n))) {
    throw new Error('Not a valid PowerPoint file (no slides found)');
  }

  opts.onProgress?.({ phase: 'extract' });
  const states: PartState[] = [];
  let nextId = 0;
  for (const name of partNames) {
    const xml = await zip.file(name)!.async('string');
    const { groups, doc, declaration } = extractGroupsFromPart(name, xml, 'a', nextId);
    nextId += groups.length;
    states.push({ name, doc, declaration, groups, order: slideOrder(name) });
  }

  const allGroups = states.flatMap((s) => s.groups);
  const segments = allGroups
    .filter((g) => g.text.trim().length > 0)
    .map((g) => ({ id: g.id, text: g.text }));
  const segmentCount = segments.length;

  opts.onProgress?.({ phase: 'translate', done: 0, total: segmentCount });
  const translations = await translate(segments, (done, total) => {
    opts.onProgress?.({ phase: 'translate', done, total });
  });

  opts.onProgress?.({ phase: 'rebuild' });
  for (const state of states) {
    applyTranslations(state.groups, translations);
    if (opts.targetRtl) {
      applyPptxRtl(state.groups, translations, opts.langTag, opts.csFont);
    }
    zip.file(state.name, serializeXml(state.doc, state.declaration));
  }

  const output = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  return { output, segmentCount };
}

/** Extract translated slide texts for the .docx reading rendition */
export async function pptxSlideTexts(input: Buffer, translations?: Map<number, string>) {
  const zip = await JSZip.loadAsync(input);
  const names: string[] = [];
  zip.forEach((p, f) => {
    if (!f.dir && /^ppt\/slides\/slide\d+\.xml$/.test(p)) names.push(p);
  });
  names.sort((a, b) => slideOrder(a) - slideOrder(b));
  const slides: { title: string; paragraphs: string[] }[] = [];
  for (const name of names) {
    const xml = await zip.file(name)!.async('string');
    const { groups } = extractGroupsFromPart(name, xml, 'a', 0);
    const paragraphs = groups
      .filter((g) => g.text.trim().length > 0)
      .map((g) => translations?.get(g.id) ?? g.text.trim());
    slides.push({ title: paragraphs[0] ?? '', paragraphs });
  }
  return slides;
}
