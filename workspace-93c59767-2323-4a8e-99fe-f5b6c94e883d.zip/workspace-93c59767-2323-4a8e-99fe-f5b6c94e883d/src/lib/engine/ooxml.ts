/**
 * Generic OOXML text-segment processor shared by DOCX / PPTX / XLSX handling.
 *
 * A "segment" is one paragraph of visible text (all text leaves grouped by
 * their nearest paragraph ancestor). Segments are extracted in document order,
 * sent to translation, then written back:
 *   - the paragraph's FIRST text leaf receives the full translation
 *     (it keeps its original run properties: bold/italic/color/size...)
 *   - the remaining text leaves are emptied (their runs keep drawings etc.)
 */
import { DOMParser, type Document, type Element } from '@xmldom/xmldom';
import {
  A_NS,
  A_RPR_ORDER,
  W_NS,
  W_PPR_ORDER,
  W_RPR_ORDER,
  childElements,
  descendantsByLocal,
  ensureChild,
  firstChildByLocal,
  insertOrdered,
  localName,
  nearestAncestor,
  setLeafText,
} from './xml';

export interface OoxmlGroup {
  /** global segment id */
  id: number;
  /** zip part this group belongs to, e.g. word/document.xml */
  part: string;
  /** paragraph element (w:p or a:p) */
  p: Element;
  /** text leaves in document order (w:t / a:t) */
  leaves: Element[];
  /** runs owning each leaf, same order (may repeat) */
  runs: Element[];
  /** concatenated text */
  text: string;
}

export interface ExtractResult {
  groups: OoxmlGroup[];
  /** serialized XML per part (only parts that were parsed) */
  parts: Map<string, string>;
}

interface LeafGrammar {
  leafLocal: string;
  paraLocal: string;
  runLocal: string;
}

const WORD: LeafGrammar = { leafLocal: 't', paraLocal: 'p', runLocal: 'r' };
const DRAWING: LeafGrammar = { leafLocal: 't', paraLocal: 'p', runLocal: 'r' };

/**
 * Extract paragraph groups from one XML part string.
 * grammar 'w' = WordprocessingML, 'a' = DrawingML (slides, charts, diagrams)
 */
export function extractGroupsFromPart(
  partName: string,
  xml: string,
  grammar: 'w' | 'a',
  startId: number,
): { groups: OoxmlGroup[]; doc: Document; declaration: string } {
  const g = grammar === 'w' ? WORD : DRAWING;
  const declaration = xml.match(/^\s*<\?xml[^>]*\?>/)?.[0];
  const doc = new DOMParser({ onError: () => undefined }).parseFromString(xml, 'text/xml');

  const leaves = descendantsByLocal(doc, [g.leafLocal]).filter((el) => {
    const ns = el.namespaceURI;
    return grammar === 'w' ? ns === W_NS : ns === A_NS || ns == null;
  });

  const groups: OoxmlGroup[] = [];
  const byPara = new Map<Element, OoxmlGroup>();

  for (const leaf of leaves) {
    const para = nearestAncestor(leaf, [g.paraLocal]);
    const run = nearestAncestor(leaf, [g.runLocal]);
    const text = leaf.textContent ?? '';
    if (!para) {
      // text leaf without a paragraph (rare, e.g. inside c:tx in charts)
      continue;
    }
    let group = byPara.get(para);
    if (!group) {
      group = { id: 0, part: partName, p: para, leaves: [], runs: [], text: '' };
      byPara.set(para, group);
      groups.push(group);
    }
    group.leaves.push(leaf);
    if (run) group.runs.push(run);
    group.text += text;
  }

  let nextId = startId;
  for (const group of groups) {
    group.id = nextId++;
    group.text = group.text.replace(/\u000b/g, '\n');
  }

  return { groups, doc, declaration: declaration ?? '' };
}

/** Write translations back into the parsed document */
export function applyTranslations(
  groups: OoxmlGroup[],
  translations: Map<number, string>,
): void {
  for (const g of groups) {
    const tr = translations.get(g.id);
    if (tr === undefined) continue;
    const first = g.leaves[0];
    if (!first) continue;
    setLeafText(first, tr);
    for (let i = 1; i < g.leaves.length; i++) setLeafText(g.leaves[i], '');
  }
}

/* ------------------------------------------------------------------ */
/* DOCX right-to-left formatting                                       */
/* ------------------------------------------------------------------ */

/**
 * Apply RTL paragraph direction + complex-script fonts to translated DOCX
 * paragraphs. Only paragraphs listed in `groups` are touched.
 */
export function applyDocxRtl(
  groups: OoxmlGroup[],
  translations: Map<number, string>,
  langBidi: string,
  csFont: string,
): void {
  for (const g of groups) {
    const tr = translations.get(g.id);
    if (tr === undefined || tr.trim().length === 0) continue;

    // Paragraph-level: <w:bidi/>
    const pPr = ensurePPr(g.p);
    const bidi = ensureChild(pPr, 'bidi', W_NS, 'w', W_PPR_ORDER);
    // an existing <w:bidi w:val="0"/> must be flipped to enabled
    const bidiVal = bidi.getAttribute('w:val');
    if (bidiVal === '0' || bidiVal === 'false') bidi.setAttribute('w:val', '1');
    else if (bidiVal !== null && bidiVal !== '1' && bidiVal !== 'true') bidi.removeAttribute('w:val');

    // Run-level: <w:rtl/>, cs font, complex-script size, proofing language
    const seenRuns = new Set<Element>();
    for (const run of g.runs) {
      if (seenRuns.has(run)) continue;
      seenRuns.add(run);
      applyRunRtl(run, langBidi, csFont);
    }
  }
}

function ensurePPr(p: Element): Element {
  const existing = firstChildByLocal(p, 'pPr');
  if (existing) return existing;
  const pPr = p.ownerDocument!.createElementNS(W_NS, 'w:pPr');
  // pPr must be the FIRST child of w:p
  const fc = p.firstChild;
  if (fc) p.insertBefore(pPr, fc);
  else p.appendChild(pPr);
  return pPr;
}

function applyRunRtl(run: Element, langBidi: string, csFont: string): void {
  let rPr = firstChildByLocal(run, 'rPr');
  if (!rPr) {
    rPr = run.ownerDocument!.createElementNS(W_NS, 'w:rPr');
    const fc = run.firstChild;
    if (fc) run.insertBefore(rPr, fc);
    else run.appendChild(rPr);
  }
  // rFonts: set/override complex-script font
  const rFonts = ensureChild(rPr, 'rFonts', W_NS, 'w', W_RPR_ORDER);
  rFonts.setAttribute('w:cs', csFont);
  // rtl flag (an existing val="0" must be flipped)
  const rtl = ensureChild(rPr, 'rtl', W_NS, 'w', W_RPR_ORDER);
  const rtlVal = rtl.getAttribute('w:val');
  if (rtlVal === '0' || rtlVal === 'false') rtl.setAttribute('w:val', '1');
  // mirror the visible size for complex scripts
  const sz = firstChildByLocal(rPr, 'sz');
  if (sz) {
    const val = sz.getAttribute('w:val');
    const szCs = ensureChild(rPr, 'szCs', W_NS, 'w', W_RPR_ORDER);
    if (val) szCs.setAttribute('w:val', val);
  }
  // proofing language
  const lang = ensureChild(rPr, 'lang', W_NS, 'w', W_RPR_ORDER);
  if (langBidi) lang.setAttribute('w:bidi', langBidi);
}

/* ------------------------------------------------------------------ */
/* PPTX right-to-left formatting                                       */
/* ------------------------------------------------------------------ */

export function applyPptxRtl(
  groups: OoxmlGroup[],
  translations: Map<number, string>,
  langTag: string,
  csFont: string,
): void {
  for (const g of groups) {
    const tr = translations.get(g.id);
    if (tr === undefined || tr.trim().length === 0) continue;

    // Paragraph: <a:pPr rtl="1"/>, flip left alignment to right
    let pPr = firstChildByLocal(g.p, 'pPr');
    if (!pPr) {
      pPr = g.p.ownerDocument!.createElementNS(A_NS, 'a:pPr');
      const fc = g.p.firstChild;
      if (fc) g.p.insertBefore(pPr, fc);
      else g.p.appendChild(pPr);
    }
    pPr.setAttribute('rtl', '1');
    if (pPr.getAttribute('algn') === 'l') pPr.setAttribute('algn', 'r');

    const seenRuns = new Set<Element>();
    for (const run of g.runs) {
      if (seenRuns.has(run)) continue;
      seenRuns.add(run);
      let rPr = firstChildByLocal(run, 'rPr');
      if (!rPr) {
        rPr = run.ownerDocument!.createElementNS(A_NS, 'a:rPr');
        const fc = run.firstChild;
        if (fc) run.insertBefore(rPr, fc);
        else run.appendChild(rPr);
      }
      rPr.setAttribute('lang', langTag);
      // <a:cs typeface="..."/> in schema position
      let cs = firstChildByLocal(rPr, 'cs');
      if (!cs) {
        cs = rPr.ownerDocument!.createElementNS(A_NS, 'a:cs');
        insertOrdered(rPr, cs, A_RPR_ORDER);
      }
      cs.setAttribute('typeface', csFont);
    }
  }
}

/* ------------------------------------------------------------------ */
/* Shared strings (XLSX)                                               */
/* ------------------------------------------------------------------ */

export interface SharedStringPart {
  doc: Document;
  declaration: string;
  /** si elements that need translation, with concatenated text */
  items: { index: number; leaves: Element[]; text: string; segmentId: number }[];
}

export function extractSharedStrings(
  xml: string,
  startId: number,
): { items: SharedStringPart['items']; doc: Document; declaration: string; nextId: number } {
  const doc = new DOMParser({ onError: () => undefined }).parseFromString(xml, 'text/xml');
  const declaration = xml.match(/^\s*<\?xml[^>]*\?>/)?.[0] ?? '';
  const items: SharedStringPart['items'] = [];
  const sis = descendantsByLocal(doc, ['si']);
  let id = startId;
  for (let i = 0; i < sis.length; i++) {
    const si = sis[i];
    const leaves = descendantsByLocal(si, ['t']);
    const text = leaves.map((t) => t.textContent ?? '').join('');
    if (text.trim().length === 0) continue;
    items.push({ index: i, leaves, text, segmentId: id++ });
  }
  return { items, doc, declaration, nextId: id };
}

export function applySharedStrings(
  items: SharedStringPart['items'],
  translations: Map<number, string>,
): void {
  for (const item of items) {
    const tr = translations.get(item.segmentId);
    if (tr === undefined) continue;
    if (item.leaves.length === 0) continue;
    setLeafText(item.leaves[0], tr);
    for (let i = 1; i < item.leaves.length; i++) setLeafText(item.leaves[i], '');
  }
}

/** helper used by rendition builders */
export function paragraphCount(groups: OoxmlGroup[]): number {
  return groups.filter((g) => g.text.trim().length > 0).length;
}

export { childElements, firstChildByLocal, localName };
