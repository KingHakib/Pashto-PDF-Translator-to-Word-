'use client';

import {
  Check,
  Download,
  Eye,
  FileSpreadsheet,
  FileText,
  Loader2,
  AlertTriangle,
  TriangleAlert,
  X,
  XCircle,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  STEPS,
  formatBytes,
  stepState,
  targetLabel,
  type JobMetaClient,
} from './types';

function statusBadge(meta: JobMetaClient) {
  if (meta.status === 'done') {
    return (
      <Badge className="gap-1 bg-emerald-600 hover:bg-emerald-600">
        <Check className="h-3 w-3" /> Done
      </Badge>
    );
  }
  if (meta.status === 'error') {
    return (
      <Badge variant="destructive" className="gap-1">
        <XCircle className="h-3 w-3" /> Failed
      </Badge>
    );
  }
  if (meta.status === 'canceled') {
    return (
      <Badge variant="outline" className="gap-1">
        <X className="h-3 w-3" /> Canceled
      </Badge>
    );
  }
  return (
    <Badge variant="outline" className="gap-1 border-emerald-600/50 text-emerald-700 dark:text-emerald-400">
      <Loader2 className="h-3 w-3 animate-spin" /> {meta.stage || 'Processing'}
    </Badge>
  );
}

export interface JobCardProps {
  job: JobMetaClient;
  onDelete: (id: string) => void;
  onCancel: (id: string) => void;
  onPreview: (job: JobMetaClient) => void;
  compact?: boolean;
}

export function JobCard({ job, onDelete, onCancel, onPreview, compact }: JobCardProps) {
  const { done, current } = stepState(job.status);
  const hasWord = job.outputs.includes('translated.docx');
  const hasPdf = job.outputs.includes('translated.pdf');
  const hasNative =
    job.outputs.includes('translated.pptx') || job.outputs.includes('translated.xlsx');
  const nativeFile = job.outputs.includes('translated.pptx')
    ? 'translated.pptx'
    : 'translated.xlsx';

  return (
    <div className="rounded-2xl border bg-card p-4 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex min-w-0 items-start gap-3">
          <div className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-600/10 text-emerald-700 dark:text-emerald-400">
            <FileText className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold" title={job.originalName}>
              {job.originalName}
            </p>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
              <span>{formatBytes(job.size)}</span>
              {job.pageCount ? <span>· {job.pageCount} pages</span> : null}
              {job.sourceLang && job.sourceLang.name !== 'Unknown' ? (
                <span>
                  · {job.sourceLang.name} →{' '}
                  <span className="font-pashto">{targetLabel(job.targetLang).split('— ').pop()}</span>
                </span>
              ) : (
                <span>· → {targetLabel(job.targetLang).split(' — ')[0]}</span>
              )}
              {job.ocr?.used ? (
                <span className="text-amber-600 dark:text-amber-400">
                  · OCR ({job.ocr.langs ?? job.ocr.script ?? 'auto'})
                </span>
              ) : null}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {statusBadge(job)}
          {!compact && !['done', 'error', 'canceled'].includes(job.status) && (
            <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Cancel translation"
              onClick={() => onCancel(job.id)}>
              <X className="h-4 w-4" />
            </Button>
          )}
          {!compact && (
            <Button variant="ghost" size="icon" className="h-8 w-8" aria-label="Delete job"
              onClick={() => onDelete(job.id)}>
              <TriangleAlert className="hidden" />
              <X className="h-4 w-4 text-muted-foreground" />
            </Button>
          )}
        </div>
      </div>

      {/* progress */}
      {!['done', 'error', 'canceled'].includes(job.status) && (
        <div className="mt-3 space-y-2">
          <Progress value={job.progress} className="h-2" />
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-muted-foreground">
            <span>
              {job.segmentsTotal
                ? `${Math.min(job.segmentsDone ?? 0, job.segmentsTotal)} / ${job.segmentsTotal} segments translated`
                : job.stage}
            </span>
            <span>{Math.round(job.progress)}%</span>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {STEPS.map((s) => {
              const isDone = done.includes(s.key);
              const isCurrent = current === s.key;
              return (
                <span
                  key={s.key}
                  className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-medium
                    ${isDone ? 'bg-emerald-600/15 text-emerald-700 dark:text-emerald-400' : ''}
                    ${isCurrent ? 'bg-emerald-600 text-white' : ''}
                    ${!isDone && !isCurrent ? 'bg-muted text-muted-foreground' : ''}`}
                >
                  {isDone ? <Check className="h-3 w-3" /> : null}
                  {s.label}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* error */}
      {job.status === 'error' && (
        <p className="mt-3 rounded-xl bg-destructive/10 px-3 py-2 text-sm text-destructive">
          {job.error ?? 'Translation failed.'}
        </p>
      )}

      {/* warnings */}
      {job.warnings.length > 0 && (
        <div className="mt-3 space-y-1 rounded-xl bg-amber-500/10 px-3 py-2">
          {job.warnings.map((w, i) => (
            <p key={i} className="flex items-start gap-2 text-xs text-amber-700 dark:text-amber-400">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              {w}
            </p>
          ))}
        </div>
      )}

      {/* actions */}
      {job.status === 'done' && (
        <>
          <Separator className="my-3" />
          <div className="flex flex-wrap items-center gap-2">
            {hasWord && (
              <Button asChild size="sm" className="gap-1.5">
                <a href={`/api/jobs/${job.id}/file?name=translated.docx`} download>
                  <Download className="h-4 w-4" /> Word (.docx)
                </a>
              </Button>
            )}
            {hasPdf && (
              <Button asChild size="sm" variant="outline" className="gap-1.5">
                <a href={`/api/jobs/${job.id}/file?name=translated.pdf`} download>
                  <Download className="h-4 w-4" /> PDF
                </a>
              </Button>
            )}
            {hasNative && (
              <Button asChild size="sm" variant="outline" className="gap-1.5">
                <a href={`/api/jobs/${job.id}/file?name=${nativeFile}`} download>
                  {nativeFile.endsWith('pptx') ? (
                    <FileSpreadsheet className="h-4 w-4" />
                  ) : (
                    <FileSpreadsheet className="h-4 w-4" />
                  )}
                  {nativeFile.endsWith('pptx') ? 'PowerPoint' : 'Excel'} (original format)
                </a>
              </Button>
            )}
            {(job.previews.original > 0 || job.previews.translated > 0) && (
              <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => onPreview(job)}>
                <Eye className="h-4 w-4" /> Preview
              </Button>
            )}
            {job.originalDeleted && (
              <span className="ml-auto text-[11px] text-muted-foreground">
                original deleted per retention setting
              </span>
            )}
          </div>
        </>
      )}
    </div>
  );
}
