'use client';

import React, { useCallback, useRef, useState } from 'react';
import { UploadCloud, FileText, X, Presentation, Sheet, FileCode, File as FileIcon } from 'lucide-react';
import { formatBytes } from './types';
import { Button } from '@/components/ui/button';

const ACCEPT = '.pdf,.docx,.doc,.pptx,.ppt,.xlsx,.xls,.txt,.rtf,.html,.odt';
const MAX_SIZE = 100 * 1024 * 1024;

const FORMAT_BADGES = [
  { ext: 'PDF', color: 'text-rose-600 bg-rose-500/10' },
  { ext: 'DOCX', color: 'text-sky-700 bg-sky-500/10' },
  { ext: 'PPTX', color: 'text-orange-600 bg-orange-500/10' },
  { ext: 'XLSX', color: 'text-emerald-700 bg-emerald-500/10' },
  { ext: 'TXT', color: 'text-slate-600 bg-slate-500/10' },
  { ext: 'RTF', color: 'text-violet-700 bg-violet-500/10' },
  { ext: 'HTML', color: 'text-amber-700 bg-amber-500/10' },
];

function iconFor(name: string) {
  const ext = name.split('.').pop()?.toLowerCase();
  if (ext === 'pdf') return <FileText className="h-4 w-4 text-rose-500" />;
  if (ext === 'docx' || ext === 'doc') return <FileText className="h-4 w-4 text-sky-600" />;
  if (ext === 'pptx' || ext === 'ppt') return <Presentation className="h-4 w-4 text-orange-500" />;
  if (ext === 'xlsx' || ext === 'xls') return <Sheet className="h-4 w-4 text-emerald-600" />;
  if (ext === 'html' || ext === 'rtf' || ext === 'odt') return <FileCode className="h-4 w-4 text-amber-600" />;
  return <FileIcon className="h-4 w-4 text-slate-500" />;
}

export interface DropzoneProps {
  files: File[];
  onChange: (files: File[]) => void;
  disabled?: boolean;
}

export function Dropzone({ files, onChange, disabled }: DropzoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const addFiles = useCallback(
    (incoming: FileList | File[]) => {
      setError(null);
      const list = Array.from(incoming);
      const valid: File[] = [];
      for (const f of list) {
        const ext = f.name.split('.').pop()?.toLowerCase() ?? '';
        const allowed = ACCEPT.split(',').includes(`.${ext}`);
        if (!allowed) {
          setError(`"${f.name}" has an unsupported format.`);
          continue;
        }
        if (f.size > MAX_SIZE) {
          setError(`"${f.name}" is larger than 100 MB.`);
          continue;
        }
        valid.push(f);
      }
      // dedupe by name+size
      const existing = new Set(files.map((f) => `${f.name}:${f.size}`));
      const merged = [...files];
      for (const f of valid) {
        const key = `${f.name}:${f.size}`;
        if (!existing.has(key)) {
          merged.push(f);
          existing.add(key);
        }
      }
      onChange(merged.slice(0, 10));
    },
    [files, onChange],
  );

  return (
    <div className="space-y-3">
      <div
        role="button"
        tabIndex={0}
        aria-label="Upload documents"
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => {
          if ((e.key === 'Enter' || e.key === ' ') && !disabled) inputRef.current?.click();
        }}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          if (!disabled) addFiles(e.dataTransfer.files);
        }}
        className={`group relative flex min-h-[220px] cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-8 text-center transition-colors
          ${dragging ? 'dropzone-active bg-emerald-500/5 border-emerald-600' : 'border-emerald-600/40 hover:bg-emerald-500/5 hover:border-emerald-600/70'}
          ${disabled ? 'pointer-events-none opacity-60' : ''}`}
      >
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-600/10 text-emerald-700 dark:text-emerald-400 transition-transform group-hover:scale-105">
          <UploadCloud className="h-8 w-8" />
        </div>
        <div>
          <p className="text-base font-semibold">Drag &amp; drop documents here</p>
          <p className="mt-1 text-sm text-muted-foreground">
            or click to browse — up to 10 files, 100 MB each
          </p>
        </div>
        <div className="mt-1 flex flex-wrap justify-center gap-1.5">
          {FORMAT_BADGES.map((b) => (
            <span
              key={b.ext}
              className={`rounded-md px-2 py-0.5 text-[11px] font-bold tracking-wide ${b.color}`}
            >
              {b.ext}
            </span>
          ))}
          <span className="rounded-md bg-slate-500/10 px-2 py-0.5 text-[11px] font-bold text-slate-600 dark:text-slate-300">
            +DOC, PPT, XLS, ODT
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          Scanned PDFs are handled automatically with OCR
        </p>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT}
          multiple
          className="hidden"
          onChange={(e) => {
            if (e.target.files) addFiles(e.target.files);
            e.target.value = '';
          }}
        />
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}

      {files.length > 0 && (
        <ul className="space-y-2">
          {files.map((f, i) => (
            <li
              key={`${f.name}:${f.size}:${i}`}
              className="flex items-center gap-3 rounded-xl border bg-card px-3 py-2"
            >
              {iconFor(f.name)}
              <span className="min-w-0 flex-1 truncate text-sm font-medium" title={f.name}>
                {f.name}
              </span>
              <span className="shrink-0 text-xs text-muted-foreground">{formatBytes(f.size)}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-7 w-7 shrink-0"
                aria-label={`Remove ${f.name}`}
                onClick={() => onChange(files.filter((_, idx) => idx !== i))}
              >
                <X className="h-4 w-4" />
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
