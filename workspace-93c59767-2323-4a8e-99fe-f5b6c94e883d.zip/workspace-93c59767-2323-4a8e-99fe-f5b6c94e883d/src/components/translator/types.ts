export interface JobMetaClient {
  id: string;
  originalName: string;
  ext: string;
  size: number;
  targetLang: string;
  retention: 'after-processing' | '24h' | 'after-download' | 'keep';
  status:
    | 'queued'
    | 'analyzing'
    | 'converting'
    | 'extracting'
    | 'detecting'
    | 'translating'
    | 'rebuilding'
    | 'exporting'
    | 'done'
    | 'error'
    | 'canceled';
  stage: string;
  progress: number;
  sourceLang?: { code: string; name: string; confidence: string } | null;
  alreadyTarget?: boolean;
  pageCount?: number;
  segmentsTotal?: number;
  segmentsDone?: number;
  ocr?: { used: boolean; script?: string; langs?: string; lowConfidencePages?: number };
  warnings: string[];
  outputs: string[];
  previews: { original: number; translated: number };
  error?: string;
  createdAt: number;
  updatedAt: number;
  completedAt?: number;
  originalDeleted?: boolean;
}

export const ACTIVE_STATUSES = new Set([
  'queued',
  'analyzing',
  'converting',
  'extracting',
  'detecting',
  'translating',
  'rebuilding',
  'exporting',
]);

export const STEPS: { key: string; label: string }[] = [
  { key: 'analyzing', label: 'Analyze' },
  { key: 'extracting', label: 'Extract' },
  { key: 'detecting', label: 'Detect' },
  { key: 'translating', label: 'Translate' },
  { key: 'rebuilding', label: 'Rebuild' },
  { key: 'exporting', label: 'Export' },
];

/** map a live status to which pipeline steps are done/current */
export function stepState(status: JobMetaClient['status']): {
  done: string[];
  current: string | null;
} {
  const order = ['analyzing', 'extracting', 'detecting', 'translating', 'rebuilding', 'exporting'];
  const converting = status === 'converting';
  if (status === 'done') return { done: order, current: null };
  if (status === 'error' || status === 'canceled' || status === 'queued') {
    return { done: [], current: null };
  }
  const idx = order.indexOf(status);
  if (idx === -1) return { done: [], current: converting ? 'analyzing' : null };
  return { done: order.slice(0, idx), current: order[idx] };
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export const TARGET_LANGS = [
  { code: 'ps', label: 'Pashto (Afghan) — پښتو', rtl: true },
  { code: 'fa', label: 'Dari / Persian — دری', rtl: true },
  { code: 'ar', label: 'Arabic — العربية', rtl: true },
  { code: 'en', label: 'English', rtl: false },
];

export function targetLabel(code: string): string {
  return TARGET_LANGS.find((l) => l.code === code)?.label ?? code;
}

export const RETENTION_OPTIONS = [
  { value: 'after-processing', label: 'Delete originals right after processing' },
  { value: '24h', label: 'Keep originals for 24 hours' },
  { value: 'after-download', label: 'Delete originals after first download' },
  { value: 'keep', label: 'Keep until I delete them' },
];
