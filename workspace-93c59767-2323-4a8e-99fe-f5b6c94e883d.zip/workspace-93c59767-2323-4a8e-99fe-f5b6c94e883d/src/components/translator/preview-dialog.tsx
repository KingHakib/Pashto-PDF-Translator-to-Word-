'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { JobMetaClient } from './types';

export function PreviewDialog({
  job,
  open,
  onOpenChange,
}: {
  job: JobMetaClient | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}) {
  const [page, setPage] = useState(1);
  if (!job) return null;

  const origPages = job.previews.original;
  const transPages = job.previews.translated;
  const maxPage = Math.max(origPages, transPages, 1);
  const safePage = Math.min(page, maxPage);

  const nav = (
    <div className="flex items-center justify-center gap-2 pb-2">
      <Button
        variant="outline"
        size="icon"
        className="h-8 w-8"
        disabled={safePage <= 1}
        onClick={() => setPage(safePage - 1)}
        aria-label="Previous page"
      >
        <ChevronLeft className="h-4 w-4" />
      </Button>
      <span className="text-sm text-muted-foreground">
        Page {safePage} / {maxPage}
      </span>
      <Button
        variant="outline"
        size="icon"
        className="h-8 w-8"
        disabled={safePage >= maxPage}
        onClick={() => setPage(safePage + 1)}
        aria-label="Next page"
      >
        <ChevronRight className="h-4 w-4" />
      </Button>
    </div>
  );

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        setPage(1);
      }}
    >
      <DialogContent className="max-h-[92vh] max-w-5xl overflow-y-auto slim-scroll">
        <DialogHeader>
          <DialogTitle className="truncate pr-6" title={job.originalName}>
            Preview — {job.originalName}
          </DialogTitle>
          <DialogDescription>
            First {maxPage} rendered page{maxPage > 1 ? 's' : ''} · original layout vs. Pashto
            translation
          </DialogDescription>
        </DialogHeader>

        {nav}

        <Tabs defaultValue="side" className="w-full">
          <TabsList className="mx-auto grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="side">Side by side</TabsTrigger>
            <TabsTrigger value="original">Original</TabsTrigger>
            <TabsTrigger value="translated">Translated</TabsTrigger>
          </TabsList>

          <TabsContent value="side" className="mt-3">
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <figure className="space-y-1.5">
                <figcaption className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Original
                </figcaption>
                <div className="overflow-hidden rounded-xl border bg-white">
                  {origPages >= safePage ? (
                    <img
                      src={`/api/jobs/${job.id}/preview?side=original&page=${safePage}`}
                      alt={`Original page ${safePage}`}
                      className="h-auto w-full"
                    />
                  ) : (
                    <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
                      No preview available
                    </div>
                  )}
                </div>
              </figure>
              <figure className="space-y-1.5">
                <figcaption className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Translated (Pashto · RTL)
                </figcaption>
                <div className="overflow-hidden rounded-xl border bg-white">
                  {transPages >= safePage ? (
                    <img
                      src={`/api/jobs/${job.id}/preview?side=translated&page=${safePage}`}
                      alt={`Translated page ${safePage}`}
                      className="h-auto w-full"
                    />
                  ) : (
                    <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
                      No preview available
                    </div>
                  )}
                </div>
              </figure>
            </div>
          </TabsContent>

          <TabsContent value="original" className="mt-3">
            <div className="overflow-hidden rounded-xl border bg-white">
              {origPages >= safePage ? (
                <img
                  src={`/api/jobs/${job.id}/preview?side=original&page=${safePage}`}
                  alt={`Original page ${safePage}`}
                  className="h-auto w-full"
                />
              ) : (
                <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
                  No preview available
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="translated" className="mt-3">
            {job.outputs.includes('translated.pdf') ? (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-xs text-muted-foreground">
                    Full PDF preview with correct RTL rendering
                  </p>
                  <Button asChild size="sm" variant="outline" className="gap-1.5">
                    <a
                      href={`/api/jobs/${job.id}/file?name=translated.pdf&inline=1`}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <ExternalLink className="h-3.5 w-3.5" /> Open full PDF
                    </a>
                  </Button>
                </div>
                <iframe
                  title="Translated PDF"
                  src={`/api/jobs/${job.id}/file?name=translated.pdf&inline=1#page=${safePage}`}
                  className="h-[60vh] w-full rounded-xl border bg-white"
                />
              </div>
            ) : transPages >= safePage ? (
              <img
                src={`/api/jobs/${job.id}/preview?side=translated&page=${safePage}`}
                alt={`Translated page ${safePage}`}
                className="h-auto w-full rounded-xl border"
              />
            ) : (
              <div className="flex h-48 items-center justify-center text-sm text-muted-foreground">
                No preview available
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
