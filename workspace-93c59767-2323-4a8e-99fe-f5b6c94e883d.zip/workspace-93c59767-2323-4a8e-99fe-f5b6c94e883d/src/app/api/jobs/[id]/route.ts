import { NextRequest, NextResponse } from 'next/server';
import { cancelJob } from '@/lib/jobs/pipeline';
import { deleteJob, ensureStore, getJob } from '@/lib/jobs/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  ensureStore();
  const { id } = await params;
  const meta = getJob(id);
  if (!meta) return NextResponse.json({ error: 'Job not found.' }, { status: 404 });
  return NextResponse.json({ job: meta });
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  ensureStore();
  const { id } = await params;
  cancelJob(id);
  const ok = deleteJob(id);
  if (!ok) return NextResponse.json({ error: 'Job not found.' }, { status: 404 });
  return NextResponse.json({ ok: true });
}
