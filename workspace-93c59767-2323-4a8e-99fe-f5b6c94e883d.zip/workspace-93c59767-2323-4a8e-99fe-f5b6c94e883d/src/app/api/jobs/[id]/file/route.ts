import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { deleteOriginalFile, ensureStore, getJob, outputsDir } from '@/lib/jobs/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_OUTPUTS: Record<string, { file: string; type: string; label: string }> = {
  'translated.docx': {
    file: 'translated.docx',
    type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    label: 'word',
  },
  'translated.pdf': { file: 'translated.pdf', type: 'application/pdf', label: 'pdf' },
  'translated.pptx': {
    file: 'translated.pptx',
    type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    label: 'powerpoint',
  },
  'translated.xlsx': {
    file: 'translated.xlsx',
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    label: 'excel',
  },
};

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  ensureStore();
  const { id } = await params;
  const meta = getJob(id);
  if (!meta) return NextResponse.json({ error: 'Job not found.' }, { status: 404 });

  const name = req.nextUrl.searchParams.get('name') ?? 'translated.docx';
  const spec = ALLOWED_OUTPUTS[name];
  if (!spec || !meta.outputs.includes(spec.file)) {
    return NextResponse.json({ error: 'Output not available.' }, { status: 404 });
  }
  const filePath = path.join(outputsDir(id), spec.file);
  if (!fs.existsSync(filePath)) {
    return NextResponse.json({ error: 'File missing on disk.' }, { status: 404 });
  }

  // retention policy: delete the original after the first successful download
  if (meta.retention === 'after-download' && !meta.originalDeleted) {
    deleteOriginalFile(id);
  }

  const baseName = meta.originalName.replace(/\.[^.]+$/, '');
  const downloadName = `${baseName}-${spec.label}.${spec.file.split('.').pop()}`;
  const inline = req.nextUrl.searchParams.get('inline') === '1';

  const buf = fs.readFileSync(filePath);
  return new NextResponse(new Uint8Array(buf), {
    headers: {
      'Content-Type': spec.type,
      'Content-Length': String(buf.length),
      'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(downloadName)}`,
      'Cache-Control': 'no-store',
    },
  });
}
