import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { ensureStore, getJob, previewsDir } from '@/lib/jobs/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  ensureStore();
  const { id } = await params;
  const meta = getJob(id);
  if (!meta) return NextResponse.json({ error: 'Job not found.' }, { status: 404 });

  const side = req.nextUrl.searchParams.get('side') === 'translated' ? 'trans' : 'orig';
  const page = Math.min(Math.max(parseInt(req.nextUrl.searchParams.get('page') ?? '1', 10) || 1, 1), 10);

  const dir = previewsDir(id);
  // pdftoppm names: orig-1.jpg / trans-1.jpg (single digit for <=9 pages)
  const candidates = [`${side}-${page}.jpg`, `${side}-${String(page).padStart(2, '0')}.jpg`];
  const found = candidates.map((c) => path.join(dir, c)).find((p) => fs.existsSync(p));
  if (!found) {
    return NextResponse.json({ error: 'Preview not found.' }, { status: 404 });
  }
  const buf = fs.readFileSync(found);
  return new NextResponse(new Uint8Array(buf), {
    headers: {
      'Content-Type': 'image/jpeg',
      'Content-Length': String(buf.length),
      'Cache-Control': 'private, max-age=3600',
    },
  });
}
