import { NextRequest, NextResponse } from 'next/server';
import { cancelJob } from '@/lib/jobs/pipeline';
import { ensureStore } from '@/lib/jobs/store';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  ensureStore();
  const { id } = await params;
  const ok = cancelJob(id);
  if (!ok) {
    return NextResponse.json({ error: 'Job cannot be canceled.' }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
