import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import {
  createJob,
  ensureStore,
  jobDir,
  listJobs,
  safeOriginalName,
  type Retention,
} from '@/lib/jobs/store';
import { enqueueJob } from '@/lib/jobs/pipeline';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ALLOWED_EXT = new Set([
  'pdf', 'docx', 'doc', 'pptx', 'ppt', 'xlsx', 'xls', 'txt', 'rtf', 'html', 'odt',
]);
const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100 MB
const MAX_BATCH = 10;

const RETENTIONS: Retention[] = ['after-processing', '24h', 'after-download', 'keep'];

export async function GET() {
  ensureStore();
  // also nudges the scheduler so queued jobs start even after a server restart
  enqueueJob();
  const jobs = listJobs();
  return NextResponse.json({ jobs });
}

export async function POST(req: NextRequest) {
  ensureStore();
  try {
    const form = await req.formData();
    const files = form.getAll('files').filter((f): f is File => f instanceof File);
    if (files.length === 0) {
      return NextResponse.json({ error: 'No files uploaded.' }, { status: 400 });
    }
    if (files.length > MAX_BATCH) {
      return NextResponse.json(
        { error: `Please upload at most ${MAX_BATCH} files at once.` },
        { status: 400 },
      );
    }
    const targetLang = String(form.get('targetLang') ?? 'ps');
    const retentionRaw = String(form.get('retention') ?? 'after-processing');
    const retention: Retention = RETENTIONS.includes(retentionRaw as Retention)
      ? (retentionRaw as Retention)
      : 'after-processing';

    const created = [];
    for (const file of files) {
      const displayName = safeOriginalName(file.name || 'document');
      const ext = (displayName.split('.').pop() ?? '').toLowerCase();
      if (!ALLOWED_EXT.has(ext)) {
        return NextResponse.json(
          {
            error: `Unsupported file type: .${ext || '?'} (${displayName}). Supported: PDF, DOCX, DOC, PPTX, PPT, XLSX, XLS, TXT, RTF, HTML, ODT.`,
          },
          { status: 400 },
        );
      }
      if (file.size > MAX_FILE_SIZE) {
        return NextResponse.json(
          { error: `${displayName} is larger than 100 MB.` },
          { status: 400 },
        );
      }
      if (file.size === 0) {
        return NextResponse.json({ error: `${displayName} is empty.` }, { status: 400 });
      }

      const meta = createJob({
        originalName: displayName,
        ext,
        size: file.size,
        targetLang,
        retention,
      });

      const buf = Buffer.from(await file.arrayBuffer());
      fs.writeFileSync(path.join(jobDir(meta.id), `original.${ext}`), buf);
      enqueueJob(meta.id);
      created.push(meta);
    }

    return NextResponse.json({ jobs: created });
  } catch (err) {
    return NextResponse.json(
      { error: err instanceof Error ? err.message : 'Upload failed.' },
      { status: 500 },
    );
  }
}
