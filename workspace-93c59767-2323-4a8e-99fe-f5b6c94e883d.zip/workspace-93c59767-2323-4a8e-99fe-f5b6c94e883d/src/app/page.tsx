'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  FileSearch,
  Languages,
  LayoutTemplate,
  Moon,
  ScanText,
  ShieldCheck,
  Sun,
  Sparkles,
  Wand2,
} from 'lucide-react';
import { useTheme } from 'next-themes';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { Dropzone } from '@/components/translator/dropzone';
import { JobCard } from '@/components/translator/job-card';
import { PreviewDialog } from '@/components/translator/preview-dialog';
import {
  ACTIVE_STATUSES,
  RETENTION_OPTIONS,
  TARGET_LANGS,
  type JobMetaClient,
} from '@/components/translator/types';

const FEATURES = [
  {
    icon: LayoutTemplate,
    title: 'Layout preserved',
    text: 'Tables, images, headers, footers, colors and fonts stay exactly where the author put them — only the words change.',
  },
  {
    icon: ScanText,
    title: 'OCR for scans',
    text: 'Image-only PDFs are read with OCR (English, Pashto, Dari, Arabic, Urdu, Chinese, Russian and more).',
  },
  {
    icon: Languages,
    title: 'Any language → Pashto',
    text: 'Automatic source-language detection and fluent, professional Afghan Pashto with proper RTL shaping.',
  },
  {
    icon: ShieldCheck,
    title: 'Private by design',
    text: 'Originals are deleted automatically after processing, after download, or after 24h — your choice.',
  },
];

const STEPS_INFO = [
  { n: 1, t: 'Upload', d: 'Drop your document — any common format.' },
  { n: 2, t: 'Analyze', d: 'We detect format, language and text structure.' },
  { n: 3, t: 'Translate', d: 'AI translates every segment — nothing skipped.' },
  { n: 4, t: 'Download', d: 'Get an editable .docx that mirrors the original.' },
];

export default function Home() {
  const { resolvedTheme, setTheme } = useTheme();
  const [files, setFiles] = useState<File[]>([]);
  const [targetLang, setTargetLang] = useState('ps');
  const [retention, setRetention] = useState('after-processing');
  const [uploading, setUploading] = useState(false);
  const [jobs, setJobs] = useState<JobMetaClient[]>([]);
  const [previewJob, setPreviewJob] = useState<JobMetaClient | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const refresh = useCallback(async () => {
    try {
      const res = await fetch('/api/jobs', { cache: 'no-store' });
      if (!res.ok) return;
      const data = (await res.json()) as { jobs: JobMetaClient[] };
      setJobs(data.jobs ?? []);
    } catch {
      /* transient */
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const hasActive = useMemo(
    () => jobs.some((j) => ACTIVE_STATUSES.has(j.status)),
    [jobs],
  );

  useEffect(() => {
    if (pollRef.current) clearInterval(pollRef.current);
    pollRef.current = setInterval(refresh, hasActive ? 1500 : 8000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [hasActive, refresh]);

  const upload = useCallback(async () => {
    if (files.length === 0) return;
    setUploading(true);
    try {
      const form = new FormData();
      for (const f of files) form.append('files', f);
      form.append('targetLang', targetLang);
      form.append('retention', retention);
      const res = await fetch('/api/jobs', { method: 'POST', body: form });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? 'Upload failed.');
        return;
      }
      toast.success(
        data.jobs.length === 1
          ? 'Translation started — you can watch the progress below.'
          : `${data.jobs.length} documents queued for translation.`,
      );
      setFiles([]);
      await refresh();
    } catch {
      toast.error('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  }, [files, targetLang, retention, refresh]);

  const deleteJob = useCallback(
    async (id: string) => {
      await fetch(`/api/jobs/${id}`, { method: 'DELETE' });
      setJobs((prev) => prev.filter((j) => j.id !== id));
      toast.info('Removed from history. All stored files were deleted.');
    },
    [],
  );

  const cancelJob = useCallback(
    async (id: string) => {
      await fetch(`/api/jobs/${id}/cancel`, { method: 'POST' });
      refresh();
    },
    [refresh],
  );

  const openPreview = useCallback((job: JobMetaClient) => {
    setPreviewJob(job);
    setPreviewOpen(true);
  }, []);

  const active = jobs.filter((j) => ACTIVE_STATUSES.has(j.status));
  const finished = jobs.filter((j) => !ACTIVE_STATUSES.has(j.status));

  return (
    <div className="flex min-h-screen flex-col">
      {/* header */}
      <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-600 to-teal-500 text-white shadow-md">
              <Languages className="h-5 w-5" />
            </div>
            <div>
              <p className="text-base font-extrabold leading-tight tracking-tight">
                PashtoLens
              </p>
              <p className="font-pashto text-xs leading-tight text-emerald-700 dark:text-emerald-400" dir="rtl">
                ژباړه په پښتو — د اسنادو بڼه ساتل کیږي
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="#how"
              className="hidden text-sm font-medium text-muted-foreground transition-colors hover:text-foreground sm:block"
            >
              How it works
            </a>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Toggle theme"
              onClick={() => setTheme(resolvedTheme === 'dark' ? 'light' : 'dark')}
            >
              <Sun className="h-5 w-5 dark:hidden" />
              <Moon className="hidden h-5 w-5 dark:block" />
            </Button>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-16">
        {/* hero */}
        <section className="py-10 text-center sm:py-14">
          <div className="mx-auto mb-4 inline-flex items-center gap-1.5 rounded-full border bg-card px-3 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
            <Sparkles className="h-3.5 w-3.5" />
            AI translation · original design preserved · editable Word output
          </div>
          <h1 className="mx-auto max-w-3xl text-balance text-3xl font-extrabold tracking-tight sm:text-5xl">
            Translate any document into{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-teal-500 bg-clip-text text-transparent">
              Pashto
            </span>
          </h1>
          <p className="mx-auto mt-4 max-w-2xl text-pretty text-muted-foreground sm:text-lg">
            Upload PDF, Word, PowerPoint, Excel or text files. PashtoLens translates every word
            into fluent Afghan Pashto and returns an editable <strong>.docx</strong> that keeps the
            original layout — tables, images, headers, footers and all.
          </p>
        </section>

        {/* upload + options */}
        <section aria-label="Upload and translate">
          <Card className="mx-auto max-w-4xl shadow-lg shadow-emerald-900/5">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Wand2 className="h-5 w-5 text-emerald-600" />
                Start a translation
              </CardTitle>
              <CardDescription>
                Automatic language detection · full-document translation · nothing summarized or
                skipped
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-5">
              <Dropzone files={files} onChange={setFiles} disabled={uploading} />

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="target-lang">
                    Translate into
                  </label>
                  <Select value={targetLang} onValueChange={setTargetLang}>
                    <SelectTrigger id="target-lang" className="w-full">
                      <SelectValue placeholder="Target language" />
                    </SelectTrigger>
                    <SelectContent>
                      {TARGET_LANGS.map((l) => (
                        <SelectItem key={l.code} value={l.code}>
                          {l.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm font-medium" htmlFor="retention">
                    Privacy — keep my original file
                  </label>
                  <Select value={retention} onValueChange={setRetention}>
                    <SelectTrigger id="retention" className="w-full">
                      <SelectValue placeholder="Retention policy" />
                    </SelectTrigger>
                    <SelectContent>
                      {RETENTION_OPTIONS.map((r) => (
                        <SelectItem key={r.value} value={r.value}>
                          {r.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button
                size="lg"
                className="w-full gap-2 text-base font-semibold"
                onClick={upload}
                disabled={files.length === 0 || uploading}
              >
                {uploading ? 'Uploading…' : `Translate ${files.length > 0 ? `${files.length} document${files.length > 1 ? 's' : ''}` : ''} → ${TARGET_LANGS.find((l) => l.code === targetLang)?.label.split(' — ')[0] ?? ''}`}
              </Button>
              <p className="text-center text-xs text-muted-foreground">
                Output: editable Word (.docx) + PDF · PowerPoint/Excel inputs also keep their
                native format
              </p>
            </CardContent>
          </Card>
        </section>

        {/* active jobs */}
        {active.length > 0 && (
          <section className="mx-auto mt-10 max-w-4xl" aria-label="Translation progress">
            <h2 className="mb-3 text-lg font-bold">In progress</h2>
            <div className="space-y-4">
              {active.map((j) => (
                <JobCard key={j.id} job={j} onDelete={deleteJob} onCancel={cancelJob} onPreview={openPreview} />
              ))}
            </div>
          </section>
        )}

        {/* history */}
        {finished.length > 0 && (
          <section className="mx-auto mt-10 max-w-4xl" aria-label="Translation history">
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-lg font-bold">History</h2>
              <span className="text-xs text-muted-foreground">
                finished jobs are removed after 7 days
              </span>
            </div>
            <div className="space-y-4">
              {finished.map((j) => (
                <JobCard key={j.id} job={j} onDelete={deleteJob} onCancel={cancelJob} onPreview={openPreview} compact />
              ))}
            </div>
          </section>
        )}

        {/* features */}
        <section className="mt-16">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {FEATURES.map((f) => (
              <Card key={f.title} className="border-muted/60">
                <CardContent className="p-5">
                  <div className="mb-3 flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600/10 text-emerald-700 dark:text-emerald-400">
                    <f.icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-sm font-bold">{f.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{f.text}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* how it works */}
        <section id="how" className="mt-16 scroll-mt-20">
          <h2 className="text-center text-2xl font-extrabold tracking-tight">How it works</h2>
          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {STEPS_INFO.map((s) => (
              <div key={s.n} className="rounded-2xl border bg-card p-5">
                <span className="inline-flex h-8 w-8 items-center justify-center rounded-full bg-emerald-600 text-sm font-bold text-white">
                  {s.n}
                </span>
                <h3 className="mt-3 text-sm font-bold">{s.t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </section>

        {/* format note */}
        <section className="mt-16">
          <Card className="mx-auto max-w-4xl border-dashed">
            <CardContent className="flex flex-col items-start gap-3 p-6 sm:flex-row sm:items-center">
              <FileSearch className="h-8 w-8 shrink-0 text-emerald-600" />
              <div className="text-sm text-muted-foreground">
                <strong className="text-foreground">Supported formats:</strong> PDF (text and
                scanned), DOCX, DOC, PPTX, PPT, XLSX, XLS, TXT, RTF, HTML, ODT — up to 100 MB and
                300 pages per file. Long documents are translated in full; progress is shown per
                segment.
              </div>
            </CardContent>
          </Card>
        </section>
      </main>

      <Separator />

      {/* sticky footer */}
      <footer className="mt-auto bg-card">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-4 py-5 text-center text-xs text-muted-foreground sm:flex-row sm:text-left">
          <p>
            <span className="font-semibold text-foreground">PashtoLens</span> — AI document
            translation with layout preservation. Files are processed on this server and deleted
            according to your retention choice.
          </p>
          <p className="font-pashto text-sm" dir="rtl">
            ستاسو اسناد خوندي پاتې کیږي — ژباړه په پښتو
          </p>
        </div>
      </footer>

      <PreviewDialog job={previewJob} open={previewOpen} onOpenChange={setPreviewOpen} />
    </div>
  );
}
